<!DOCTYPE html>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	
	<meta name='robots' content='noindex, follow' />
	<style>img:is([sizes="auto" i], [sizes^="auto," i]) { contain-intrinsic-size: 3000px 1500px }</style>
	
	<!-- This site is optimized with the Yoast SEO plugin v24.5 - https://yoast.com/wordpress/plugins/seo/ -->
	<title>Page not found - Muezzin</title>
	<meta property="og:locale" content="en_US" />
	<meta property="og:title" content="Page not found - Muezzin" />
	<meta property="og:site_name" content="Muezzin" />
	<script type="application/ld+json" class="yoast-schema-graph">{"@context":"https://schema.org","@graph":[{"@type":"WebSite","@id":"https://naudummy.com/muezzin/#website","url":"https://naudummy.com/muezzin/","name":"Muezzin","description":"Islamic Center WordPress Theme","publisher":{"@id":"https://naudummy.com/muezzin/#organization"},"potentialAction":[{"@type":"SearchAction","target":{"@type":"EntryPoint","urlTemplate":"https://naudummy.com/muezzin/?s={search_term_string}"},"query-input":{"@type":"PropertyValueSpecification","valueRequired":true,"valueName":"search_term_string"}}],"inLanguage":"en-US"},{"@type":"Organization","@id":"https://naudummy.com/muezzin/#organization","name":"Muezzin Islamic WordPress Theme","url":"https://naudummy.com/muezzin/","logo":{"@type":"ImageObject","inLanguage":"en-US","@id":"https://naudummy.com/muezzin/#/schema/logo/image/","url":"https://naudummy.com/muezzin/wp-content/uploads/2024/03/theme-preview.jpg","contentUrl":"https://naudummy.com/muezzin/wp-content/uploads/2024/03/theme-preview.jpg","width":590,"height":300,"caption":"Muezzin Islamic WordPress Theme"},"image":{"@id":"https://naudummy.com/muezzin/#/schema/logo/image/"},"sameAs":["https://www.facebook.com/profile.php?id=61552552883066","https://x.com/NauthemesSocial"]}]}</script>
	<!-- / Yoast SEO plugin. -->


<link rel='dns-prefetch' href='//code.jivosite.com' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='preconnect' href='https://fonts.gstatic.com' crossorigin />
<script type="text/javascript">
/* <![CDATA[ */
window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/15.0.3\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/15.0.3\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/naudummy.com\/muezzin\/wp-includes\/js\/wp-emoji-release.min.js?ver=6.7.2"}};
/*! This file is auto-generated */
!function(i,n){var o,s,e;function c(e){try{var t={supportTests:e,timestamp:(new Date).valueOf()};sessionStorage.setItem(o,JSON.stringify(t))}catch(e){}}function p(e,t,n){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);var t=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data),r=(e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(n,0,0),new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data));return t.every(function(e,t){return e===r[t]})}function u(e,t,n){switch(t){case"flag":return n(e,"\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f","\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f")?!1:!n(e,"\ud83c\uddfa\ud83c\uddf3","\ud83c\uddfa\u200b\ud83c\uddf3")&&!n(e,"\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f","\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");case"emoji":return!n(e,"\ud83d\udc26\u200d\u2b1b","\ud83d\udc26\u200b\u2b1b")}return!1}function f(e,t,n){var r="undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?new OffscreenCanvas(300,150):i.createElement("canvas"),a=r.getContext("2d",{willReadFrequently:!0}),o=(a.textBaseline="top",a.font="600 32px Arial",{});return e.forEach(function(e){o[e]=t(a,e,n)}),o}function t(e){var t=i.createElement("script");t.src=e,t.defer=!0,i.head.appendChild(t)}"undefined"!=typeof Promise&&(o="wpEmojiSettingsSupports",s=["flag","emoji"],n.supports={everything:!0,everythingExceptFlag:!0},e=new Promise(function(e){i.addEventListener("DOMContentLoaded",e,{once:!0})}),new Promise(function(t){var n=function(){try{var e=JSON.parse(sessionStorage.getItem(o));if("object"==typeof e&&"number"==typeof e.timestamp&&(new Date).valueOf()<e.timestamp+604800&&"object"==typeof e.supportTests)return e.supportTests}catch(e){}return null}();if(!n){if("undefined"!=typeof Worker&&"undefined"!=typeof OffscreenCanvas&&"undefined"!=typeof URL&&URL.createObjectURL&&"undefined"!=typeof Blob)try{var e="postMessage("+f.toString()+"("+[JSON.stringify(s),u.toString(),p.toString()].join(",")+"));",r=new Blob([e],{type:"text/javascript"}),a=new Worker(URL.createObjectURL(r),{name:"wpTestEmojiSupports"});return void(a.onmessage=function(e){c(n=e.data),a.terminate(),t(n)})}catch(e){}c(n=f(s,u,p))}t(n)}).then(function(e){for(var t in e)n.supports[t]=e[t],n.supports.everything=n.supports.everything&&n.supports[t],"flag"!==t&&(n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&n.supports[t]);n.supports.everythingExceptFlag=n.supports.everythingExceptFlag&&!n.supports.flag,n.DOMReady=!1,n.readyCallback=function(){n.DOMReady=!0}}).then(function(){return e}).then(function(){var e;n.supports.everything||(n.readyCallback(),(e=n.source||{}).concatemoji?t(e.concatemoji):e.wpemoji&&e.twemoji&&(t(e.twemoji),t(e.wpemoji)))}))}((window,document),window._wpemojiSettings);
/* ]]> */
</script>
<link rel='stylesheet' id='animate-css' href='https://naudummy.com/muezzin/wp-content/plugins/ingeniofy/css/animate.min.css?ver=6.7.2' type='text/css' media='all' />
<link rel='stylesheet' id='owl-carousel-css' href='https://naudummy.com/muezzin/wp-content/plugins/ingeniofy/css/owl.carousel.min.css?ver=6.7.2' type='text/css' media='all' />
<style id='wp-emoji-styles-inline-css' type='text/css'>

	img.wp-smiley, img.emoji {
		display: inline !important;
		border: none !important;
		box-shadow: none !important;
		height: 1em !important;
		width: 1em !important;
		margin: 0 0.07em !important;
		vertical-align: -0.1em !important;
		background: none !important;
		padding: 0 !important;
	}
</style>
<link rel='stylesheet' id='wp-block-library-css' href='https://naudummy.com/muezzin/wp-includes/css/dist/block-library/style.min.css?ver=6.7.2' type='text/css' media='all' />
<style id='create-block-campaignblock-style-inline-css' type='text/css'>
/*!***************************************************************************************************************************************************************************************************************************************!*\
  !*** css ./node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[4].use[1]!./node_modules/postcss-loader/dist/cjs.js??ruleSet[1].rules[4].use[2]!./node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[4].use[3]!./src/style.scss ***!
  \***************************************************************************************************************************************************************************************************************************************/
/**
 * The following styles get applied both on the front of your site
 * and in the editor.
 *
 * Replace them with your own styles or remove the file completely.
 */
.wp-block-create-block-campaignblock {
  background-color: white;
  padding: 20px;
  text-align: center;
}

.wp-block-create-block-campaignblock .charitable-logo {
  margin-left: auto;
  margin-right: auto;
  display: table;
}

/*# sourceMappingURL=style-index.css.map*/
</style>
<style id='charitable-campaigns-block-style-inline-css' type='text/css'>
/*!***************************************************************************************************************************************************************************************************************************************!*\
  !*** css ./node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[4].use[1]!./node_modules/postcss-loader/dist/cjs.js??ruleSet[1].rules[4].use[2]!./node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[4].use[3]!./src/style.scss ***!
  \***************************************************************************************************************************************************************************************************************************************/
/**
 * The following styles get applied both on the front of your site
 * and in the editor.
 *
 * Replace them with your own styles or remove the file completely.
 */
 .wp-block-charitable-campaigns-block {
  background-color: white;
  padding: 20px;
  text-align: center;
}
.wp-block-charitable-campaigns-block h5 {
  margin: 0 auto;
  margin-top: 0 !important;
  margin-bottom: 0px !important;
}
.wp-block-charitable-campaigns-block p {
  font-size: 11px;
  line-height: 16px;
  text-align: center;
  font-weight: 400;
  font-family: "Inter var", -apple-system, BlinkMacSystemFont, "Helvetica Neue", Helvetica, sans-serif !important;
}
.wp-block-charitable-campaigns-block .charitable-logo {
  margin-left: auto;
  margin-right: auto;
  display: table;
}
/*# sourceMappingURL=style-index.css.map*/
</style>
<style id='charitable-donations-block-style-inline-css' type='text/css'>
/*!***************************************************************************************************************************************************************************************************************************************!*\
  !*** css ./node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[4].use[1]!./node_modules/postcss-loader/dist/cjs.js??ruleSet[1].rules[4].use[2]!./node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[4].use[3]!./src/style.scss ***!
  \***************************************************************************************************************************************************************************************************************************************/
/**
 * The following styles get applied both on the front of your site
 * and in the editor.
 *
 * Replace them with your own styles or remove the file completely.
 */
 .wp-block-charitable-donations-block {
  background-color: white;
  padding: 20px;
  text-align: center;
}
.wp-block-charitable-donations-block h5 {
  margin: 0 auto;
  margin-top: 0 !important;
  margin-bottom: 0px !important;
}
.wp-block-charitable-donations-block p {
  font-size: 11px;
  line-height: 16px;
  text-align: center;
  font-weight: 400;
  font-family: "Inter var", -apple-system, BlinkMacSystemFont, "Helvetica Neue", Helvetica, sans-serif !important;
}
.wp-block-charitable-donations-block .charitable-logo {
  margin-left: auto;
  margin-right: auto;
  display: table;
}
/*# sourceMappingURL=style-index.css.map*/
</style>
<style id='charitable-donors-block-style-inline-css' type='text/css'>
/*!***************************************************************************************************************************************************************************************************************************************!*\
  !*** css ./node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[4].use[1]!./node_modules/postcss-loader/dist/cjs.js??ruleSet[1].rules[4].use[2]!./node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[4].use[3]!./src/style.scss ***!
  \***************************************************************************************************************************************************************************************************************************************/
/**
 * The following styles get applied both on the front of your site
 * and in the editor.
 *
 * Replace them with your own styles or remove the file completely.
 */
.wp-block-charitable-donors-block {
  background-color: white;
  padding: 20px;
  text-align: center;
}

.wp-block-charitable-donors-block h5 {
  margin: 0 auto;
  margin-top: 0 !important;
  margin-bottom: 0px !important;
}

.wp-block-charitable-donors-block p {
  font-size: 11px;
  line-height: 16px;
  text-align: center;
  font-weight: 400;
  font-family: "Inter var", -apple-system, BlinkMacSystemFont, "Helvetica Neue", Helvetica, sans-serif !important;
}

.wp-block-charitable-donors-block .charitable-logo {
  margin-left: auto;
  margin-right: auto;
  display: table;
}

/*# sourceMappingURL=style-index.css.map*/
</style>
<style id='charitable-donation-button-style-inline-css' type='text/css'>
/*!***************************************************************************************************************************************************************************************************************************************!*\
  !*** css ./node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[4].use[1]!./node_modules/postcss-loader/dist/cjs.js??ruleSet[1].rules[4].use[2]!./node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[4].use[3]!./src/style.scss ***!
  \***************************************************************************************************************************************************************************************************************************************/
/**
 * The following styles get applied both on the front of your site
 * and in the editor.
 *
 * Replace them with your own styles or remove the file completely.
 */
 .wp-block-charitable-donation-button {
  background-color: white;
  padding: 20px;
  text-align: center;
}
.wp-block-charitable-donation-button h5 {
  margin: 0 auto;
  margin-top: 0 !important;
  margin-bottom: 0px !important;
}
.wp-block-charitable-donation-button p {
  font-size: 11px;
  line-height: 16px;
  text-align: center;
  font-weight: 400;
  font-family: "Inter var", -apple-system, BlinkMacSystemFont, "Helvetica Neue", Helvetica, sans-serif !important;
}
.wp-block-charitable-donation-button .charitable-logo {
  margin-left: auto;
  margin-right: auto;
  display: table;
}

/*# sourceMappingURL=style-index.css.map*/
</style>
<style id='charitable-campaign-progress-bar-style-inline-css' type='text/css'>
/*!***************************************************************************************************************************************************************************************************************************************!*\
  !*** css ./node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[4].use[1]!./node_modules/postcss-loader/dist/cjs.js??ruleSet[1].rules[4].use[2]!./node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[4].use[3]!./src/style.scss ***!
  \***************************************************************************************************************************************************************************************************************************************/
/**
 * The following styles get applied both on the front of your site
 * and in the editor.
 *
 * Replace them with your own styles or remove the file completely.
 */
.wp-block-charitable-campaign-progress-bar {
  background-color: white;
  padding: 20px;
  text-align: center;
}

.wp-block-charitable-campaign-progress-bar h5 {
  margin: 0 auto;
  margin-top: 0 !important;
  margin-bottom: 0px !important;
}

.wp-block-charitable-campaign-progress-bar p {
  font-size: 11px;
  line-height: 16px;
  text-align: center;
  font-weight: 400;
  font-family: "Inter var", -apple-system, BlinkMacSystemFont, "Helvetica Neue", Helvetica, sans-serif !important;
}

.wp-block-charitable-campaign-progress-bar .charitable-logo {
  margin-left: auto;
  margin-right: auto;
  display: table;
}

/*# sourceMappingURL=style-index.css.map*/
</style>
<style id='charitable-campaign-stats-style-inline-css' type='text/css'>
/*!***************************************************************************************************************************************************************************************************************************************!*\
  !*** css ./node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[4].use[1]!./node_modules/postcss-loader/dist/cjs.js??ruleSet[1].rules[4].use[2]!./node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[4].use[3]!./src/style.scss ***!
  \***************************************************************************************************************************************************************************************************************************************/
/**
 * The following styles get applied both on the front of your site
 * and in the editor.
 *
 * Replace them with your own styles or remove the file completely.
 */
.wp-block-charitable-campaign-stats {
  background-color: white;
  padding: 20px;
  text-align: center;
}

.wp-block-charitable-campaign-stats h5 {
  margin: 0 auto;
  margin-top: 0 !important;
  margin-bottom: 0px !important;
}

.wp-block-charitable-campaign-stats p {
  font-size: 11px;
  line-height: 16px;
  text-align: center;
  font-weight: 400;
  font-family: "Inter var", -apple-system, BlinkMacSystemFont, "Helvetica Neue", Helvetica, sans-serif !important;
}

.wp-block-charitable-campaign-stats .charitable-logo {
  margin-left: auto;
  margin-right: auto;
  display: table;
}

/*# sourceMappingURL=style-index.css.map*/
</style>
<style id='charitable-my-donations-style-inline-css' type='text/css'>
/*!***************************************************************************************************************************************************************************************************************************************!*\
  !*** css ./node_modules/css-loader/dist/cjs.js??ruleSet[1].rules[4].use[1]!./node_modules/postcss-loader/dist/cjs.js??ruleSet[1].rules[4].use[2]!./node_modules/sass-loader/dist/cjs.js??ruleSet[1].rules[4].use[3]!./src/style.scss ***!
  \***************************************************************************************************************************************************************************************************************************************/
/**
 * The following styles get applied both on the front of your site
 * and in the editor.
 *
 * Replace them with your own styles or remove the file completely.
 */
.wp-block-charitable-my-donations {
  background-color: white;
  padding: 20px;
  text-align: center;
}

.wp-block-charitable-my-donations h5 {
  margin: 0 auto;
  margin-top: 0 !important;
  margin-bottom: 0px !important;
}

.wp-block-charitable-my-donations p {
  font-size: 11px;
  line-height: 16px;
  text-align: center;
  font-weight: 400;
  font-family: "Inter var", -apple-system, BlinkMacSystemFont, "Helvetica Neue", Helvetica, sans-serif !important;
}

.wp-block-charitable-my-donations .charitable-logo {
  margin-left: auto;
  margin-right: auto;
  display: table;
}

/*# sourceMappingURL=style-index.css.map*/
</style>
<style id='classic-theme-styles-inline-css' type='text/css'>
/*! This file is auto-generated */
.wp-block-button__link{color:#fff;background-color:#32373c;border-radius:9999px;box-shadow:none;text-decoration:none;padding:calc(.667em + 2px) calc(1.333em + 2px);font-size:1.125em}.wp-block-file__button{background:#32373c;color:#fff;text-decoration:none}
</style>
<style id='global-styles-inline-css' type='text/css'>
:root{--wp--preset--aspect-ratio--square: 1;--wp--preset--aspect-ratio--4-3: 4/3;--wp--preset--aspect-ratio--3-4: 3/4;--wp--preset--aspect-ratio--3-2: 3/2;--wp--preset--aspect-ratio--2-3: 2/3;--wp--preset--aspect-ratio--16-9: 16/9;--wp--preset--aspect-ratio--9-16: 9/16;--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);--wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);}:where(.is-layout-flex){gap: 0.5em;}:where(.is-layout-grid){gap: 0.5em;}body .is-layout-flex{display: flex;}.is-layout-flex{flex-wrap: wrap;align-items: center;}.is-layout-flex > :is(*, div){margin: 0;}body .is-layout-grid{display: grid;}.is-layout-grid > :is(*, div){margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}
:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}
:root :where(.wp-block-pullquote){font-size: 1.5em;line-height: 1.6;}
</style>
<link rel='stylesheet' id='contact-form-7-css' href='https://naudummy.com/muezzin/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=6.0.6' type='text/css' media='all' />
<link rel='stylesheet' id='events-manager-css' href='https://naudummy.com/muezzin/wp-content/plugins/events-manager/includes/css/events-manager.min.css?ver=6.6.4.4' type='text/css' media='all' />
<style id='events-manager-inline-css' type='text/css'>
body .em { --font-family : inherit; --font-weight : inherit; --font-size : 1em; --line-height : inherit; }
</style>
<link rel='stylesheet' id='charitable-styles-css' href='https://naudummy.com/muezzin/wp-content/plugins/charitable/assets/css/charitable.min.css?ver=1.8.4.8' type='text/css' media='all' />
<link rel='stylesheet' id='dashicons-css' href='https://naudummy.com/muezzin/wp-includes/css/dashicons.min.css?ver=6.7.2' type='text/css' media='all' />
<link rel='stylesheet' id='bootstrap-css' href='https://naudummy.com/muezzin/wp-content/themes/taqwa/assets/css/bootstrap.css?ver=6.7.2' type='text/css' media='all' />
<link rel='stylesheet' id='webfonts-css' href='https://naudummy.com/muezzin/wp-content/themes/taqwa/assets/css/webfonts.css?ver=6.7.2' type='text/css' media='all' />
<link rel='stylesheet' id='taqwa-wp-developers-css' href='https://naudummy.com/muezzin/wp-content/themes/taqwa/assets/css/themecss/wp-developer.css?ver=6.7.2' type='text/css' media='all' />
<link rel='stylesheet' id='fancybox-css' href='https://naudummy.com/muezzin/wp-content/themes/taqwa/assets/css/themecss/fancybox.min.css?ver=6.7.2' type='text/css' media='all' />
<link rel='stylesheet' id='taqwa-ttstyles-css' href='https://naudummy.com/muezzin/wp-content/themes/taqwa/assets/css/themecss/ttstyles.css?ver=6.7.2' type='text/css' media='all' />
<link rel='stylesheet' id='taqwa-default-css' href='https://naudummy.com/muezzin/wp-content/themes/taqwa/style.css?ver=6.7.2' type='text/css' media='all' />
<link rel='stylesheet' id='taqwa-responsive-css' href='https://naudummy.com/muezzin/wp-content/themes/taqwa/assets/css/themecss/responsive.css?ver=6.7.2' type='text/css' media='all' />
<style id='akismet-widget-style-inline-css' type='text/css'>

			.a-stats {
				--akismet-color-mid-green: #357b49;
				--akismet-color-white: #fff;
				--akismet-color-light-grey: #f6f7f7;

				max-width: 350px;
				width: auto;
			}

			.a-stats * {
				all: unset;
				box-sizing: border-box;
			}

			.a-stats strong {
				font-weight: 600;
			}

			.a-stats a.a-stats__link,
			.a-stats a.a-stats__link:visited,
			.a-stats a.a-stats__link:active {
				background: var(--akismet-color-mid-green);
				border: none;
				box-shadow: none;
				border-radius: 8px;
				color: var(--akismet-color-white);
				cursor: pointer;
				display: block;
				font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen-Sans', 'Ubuntu', 'Cantarell', 'Helvetica Neue', sans-serif;
				font-weight: 500;
				padding: 12px;
				text-align: center;
				text-decoration: none;
				transition: all 0.2s ease;
			}

			/* Extra specificity to deal with TwentyTwentyOne focus style */
			.widget .a-stats a.a-stats__link:focus {
				background: var(--akismet-color-mid-green);
				color: var(--akismet-color-white);
				text-decoration: none;
			}

			.a-stats a.a-stats__link:hover {
				filter: brightness(110%);
				box-shadow: 0 4px 12px rgba(0, 0, 0, 0.06), 0 0 2px rgba(0, 0, 0, 0.16);
			}

			.a-stats .count {
				color: var(--akismet-color-white);
				display: block;
				font-size: 1.5em;
				line-height: 1.4;
				padding: 0 13px;
				white-space: nowrap;
			}
		
</style>
<link rel="preload" as="style" href="https://fonts.googleapis.com/css?family=Cinzel%20Decorative:400,700,900%7CEpilogue:100,200,300,400,500,600,700,800,900,100italic,200italic,300italic,400italic,500italic,600italic,700italic,800italic,900italic&#038;subset=latin&#038;display=swap&#038;ver=1735727163" /><link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Cinzel%20Decorative:400,700,900%7CEpilogue:100,200,300,400,500,600,700,800,900,100italic,200italic,300italic,400italic,500italic,600italic,700italic,800italic,900italic&#038;subset=latin&#038;display=swap&#038;ver=1735727163" media="print" onload="this.media='all'"><noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Cinzel%20Decorative:400,700,900%7CEpilogue:100,200,300,400,500,600,700,800,900,100italic,200italic,300italic,400italic,500italic,600italic,700italic,800italic,900italic&#038;subset=latin&#038;display=swap&#038;ver=1735727163" /></noscript><script type="text/javascript" src="https://naudummy.com/muezzin/wp-content/plugins/charitable/assets/js/libraries/js-cookie.min.js?ver=2.1.4" id="js-cookie-js"></script>
<script type="text/javascript" id="charitable-sessions-js-extra">
/* <![CDATA[ */
var CHARITABLE_SESSION = {"ajaxurl":"https:\/\/naudummy.com\/muezzin\/wp-admin\/admin-ajax.php","id":"","cookie_name":"charitable_session","expiration":"86400","expiration_variant":"82800","secure":"","cookie_path":"\/muezzin\/","cookie_domain":"","generated_id":"fd824a1746722b4b606f9cf6544044e6","disable_cookie":""};
/* ]]> */
</script>
<script type="text/javascript" src="https://naudummy.com/muezzin/wp-content/plugins/charitable/assets/js/charitable-session.min.js?ver=1.8.4.8" id="charitable-sessions-js"></script>
<script type="text/javascript" src="https://naudummy.com/muezzin/wp-includes/js/jquery/jquery.min.js?ver=3.7.1" id="jquery-core-js"></script>
<script type="text/javascript" src="https://naudummy.com/muezzin/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1" id="jquery-migrate-js"></script>
<script type="text/javascript" src="https://naudummy.com/muezzin/wp-includes/js/jquery/ui/core.min.js?ver=1.13.3" id="jquery-ui-core-js"></script>
<script type="text/javascript" src="https://naudummy.com/muezzin/wp-includes/js/jquery/ui/mouse.min.js?ver=1.13.3" id="jquery-ui-mouse-js"></script>
<script type="text/javascript" src="https://naudummy.com/muezzin/wp-includes/js/jquery/ui/sortable.min.js?ver=1.13.3" id="jquery-ui-sortable-js"></script>
<script type="text/javascript" src="https://naudummy.com/muezzin/wp-includes/js/jquery/ui/datepicker.min.js?ver=1.13.3" id="jquery-ui-datepicker-js"></script>
<script type="text/javascript" id="jquery-ui-datepicker-js-after">
/* <![CDATA[ */
jQuery(function(jQuery){jQuery.datepicker.setDefaults({"closeText":"Close","currentText":"Today","monthNames":["January","February","March","April","May","June","July","August","September","October","November","December"],"monthNamesShort":["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],"nextText":"Next","prevText":"Previous","dayNames":["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],"dayNamesShort":["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],"dayNamesMin":["S","M","T","W","T","F","S"],"dateFormat":"MM d, yy","firstDay":1,"isRTL":false});});
/* ]]> */
</script>
<script type="text/javascript" src="https://naudummy.com/muezzin/wp-includes/js/jquery/ui/resizable.min.js?ver=1.13.3" id="jquery-ui-resizable-js"></script>
<script type="text/javascript" src="https://naudummy.com/muezzin/wp-includes/js/jquery/ui/draggable.min.js?ver=1.13.3" id="jquery-ui-draggable-js"></script>
<script type="text/javascript" src="https://naudummy.com/muezzin/wp-includes/js/jquery/ui/controlgroup.min.js?ver=1.13.3" id="jquery-ui-controlgroup-js"></script>
<script type="text/javascript" src="https://naudummy.com/muezzin/wp-includes/js/jquery/ui/checkboxradio.min.js?ver=1.13.3" id="jquery-ui-checkboxradio-js"></script>
<script type="text/javascript" src="https://naudummy.com/muezzin/wp-includes/js/jquery/ui/button.min.js?ver=1.13.3" id="jquery-ui-button-js"></script>
<script type="text/javascript" src="https://naudummy.com/muezzin/wp-includes/js/jquery/ui/dialog.min.js?ver=1.13.3" id="jquery-ui-dialog-js"></script>
<script type="text/javascript" id="events-manager-js-extra">
/* <![CDATA[ */
var EM = {"ajaxurl":"https:\/\/naudummy.com\/muezzin\/wp-admin\/admin-ajax.php","locationajaxurl":"https:\/\/naudummy.com\/muezzin\/wp-admin\/admin-ajax.php?action=locations_search","firstDay":"1","locale":"en","dateFormat":"yy-mm-dd","ui_css":"https:\/\/naudummy.com\/muezzin\/wp-content\/plugins\/events-manager\/includes\/css\/jquery-ui\/build.min.css","show24hours":"0","is_ssl":"1","autocomplete_limit":"10","calendar":{"breakpoints":{"small":560,"medium":908,"large":false}},"phone":"","datepicker":{"format":"d\/m\/Y"},"search":{"breakpoints":{"small":650,"medium":850,"full":false}},"url":"https:\/\/naudummy.com\/muezzin\/wp-content\/plugins\/events-manager","assets":{"input.em-uploader":{"js":{"em-uploader":{"url":"https:\/\/naudummy.com\/muezzin\/wp-content\/plugins\/events-manager\/includes\/js\/em-uploader.js","required":true,"event":"em_uploader_ready"}}}},"bookingInProgress":"Please wait while the booking is being submitted.","tickets_save":"Save Ticket","bookingajaxurl":"https:\/\/naudummy.com\/muezzin\/wp-admin\/admin-ajax.php","bookings_export_save":"Export Bookings","bookings_settings_save":"Save Settings","booking_delete":"Are you sure you want to delete?","booking_offset":"30","bookings":{"submit_button":{"text":{"default":"Send your booking","free":"Send your booking","payment":"Send your booking","processing":"Processing ..."}},"update_listener":""},"bb_full":"Sold Out","bb_book":"Book Now","bb_booking":"Booking...","bb_booked":"Booking Submitted","bb_error":"Booking Error. Try again?","bb_cancel":"Cancel","bb_canceling":"Canceling...","bb_cancelled":"Cancelled","bb_cancel_error":"Cancellation Error. Try again?","txt_search":"Search","txt_searching":"Searching...","txt_loading":"Loading..."};
/* ]]> */
</script>
<script type="text/javascript" src="https://naudummy.com/muezzin/wp-content/plugins/events-manager/includes/js/events-manager.js?ver=6.6.4.4" id="events-manager-js"></script>
<link rel="https://api.w.org/" href="https://naudummy.com/muezzin/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://naudummy.com/muezzin/xmlrpc.php?rsd" />

<meta name="generator" content="Redux 4.5.6" /><style id="stylesheet">body{background:#FFFFFF;}.news_ticker_sec span{ background: #5D2B00}#triangle-right{ border-left: 25px solid #5D2B00}#add_payment_method .wc-proceed-to-checkout a.checkout-button,.breadcrumb::before,.calendar_wrap>table caption,.calendar_wrap>table tbody td#today,.date-box,.dnt-lst>a:focus,.dnt-lst>a:hover,.em-booking-buttons input[type=submit],.em-booking-login-form>input[type=submit],.em-pagination .next:focus,.em-pagination .next:hover,.em-pagination .prev:focus,.em-pagination .prev:hover,.em-pagination a:focus,.em-pagination a:hover,.em-pagination span,.event-detail-desc ul>li:before,.event-detail-img .countdown:before,.event-detail-img>span:before,.event-thmb .countdown:before,.event-thmb>span:before,.featured-area-wrap .owl-carousel button.owl-dot.active,.lgn-rgstr-frm input[type=submit],.member-expr-lst>li:before,.owl-carousel .owl-nav>button.owl-next,.owl-carousel .owl-nav>button.owl-prev,.page+span.edit-link>a:focus,.page+span.edit-link>a:hover,.page-links>a:focus,.page-links>a:hover,.page-links>span,.page>span.edit-link>a:focus,.page>span.edit-link>a:hover,.pagination>li a:focus,.pagination>li.active span,.pagination>li:hover a,.plr-bx>i:after,.plyr.v4 .player .volume .volume-btn,.post-password-form input[type=submit],.pr-tm-lst .pr-tm-bx.spc-pr-tm,.preloader,.rspn-mnu-btn:hover,.rspn-mnu-cls:hover,.rspn-scil>li a:hover,.serv-bx2:hover .serv-inf2,.serv-bx:hover .srv-inf.green-bg,.social-share2>a:focus,.social-share2>a:hover,.srch-cls-btn:hover,.tag-sticky-2 .post-bx .post-inf:before,.tagcloud>a,.team-bx:hover .team-inf,.team-inf>span:before,.theme-bg,.theme-bg-layer:before,.theme-btn.green-bg:after,.theme-btn.green-bg:before,.widget table caption,.widget.style2>h5::before,.woocommerce #respond input#submit,.woocommerce #respond input#submit.alt,.woocommerce .cart .button,.woocommerce .cart input.button,.woocommerce .woocommerce-error .button,.woocommerce .woocommerce-info .button,.woocommerce .woocommerce-message .button,.woocommerce a.button,.woocommerce a.button.alt,.woocommerce a.remove,.woocommerce button.button,.woocommerce button.button.alt,.woocommerce div.product form.cart .button,.woocommerce input.button,.woocommerce input.button.alt,.woocommerce nav.woocommerce-pagination ul li a:focus,.woocommerce nav.woocommerce-pagination ul li a:hover,.woocommerce nav.woocommerce-pagination ul li span.current,.woocommerce span.onsale,.woocommerce ul.products li.product a,.woocommerce-cart .wc-proceed-to-checkout a.checkout-button,.woocommerce-cart table.cart th,.woocommerce-checkout .wc-proceed-to-checkout a.checkout-button,.woocommerce-page .woocommerce-error .button,.woocommerce-page .woocommerce-info .button,.woocommerce-page .woocommerce-message .button,.wp-block-button .wp-block-button__link:focus,.wp-block-button .wp-block-button__link:hover,.wp-block-tag-cloud>a,a.page-item.brd-rd5.active,body.woocommerce div.product .woocommerce-tabs ul.tabs li.active,form.wp-block-search button,nav>div>ul li>a:after,nav>div>ul li>a:before,table#wp-calendar caption,table#wp-calendar tbody td#today, .tq-support-cause-stats .progress-bar
		{
			background-color:#DB9E30 !important; 
		}.pr-tm-wrp:before {
			background-image: linear-gradient(120deg, #DB9E30, #004B39) !important;
		}.tag-clouds > span, .pst-shr-tgs .scl1 > span, #cancel-comment-reply-link,.abt-vdo>a:focus,.abt-vdo>a:hover,.blog-detail-desc>h2+ol li a,.blog-detail-desc>h2+ul li a,.breadcrumb>li a:focus,.breadcrumb>li a:hover,.cause-inf>h5 a:focus,.cause-inf>h5 a:hover,.cnt-inf-lst>li a:focus,.cnt-inf-lst>li a:hover,.cnt-inf>li a:focus,.cnt-inf>li a:hover,.cont-frm a:focus,.cont-frm a:hover,.cpy-rgt>p a:focus,.cpy-rgt>p a:hover,.em-pagination a:focus,.em-pagination a:hover,.em-pagination span,.event-bx:hover>a:focus,.event-bx:hover>a:hover,.event-bx>a:focus,.event-bx>a:hover,.event-bx>h5 a:focus,.event-bx>h5 a:hover,.event-inf>a:focus,.event-inf>a:hover,.event-inf>h5 a:focus,.event-inf>h5 a:hover,.header-search form>button:focus,.header-search form>button:hover,.inf-lst>li a:focus,.inf-lst>li a:hover,.ins,.light_mode .pr-tm-bx>span,.lst-cas>h6 a:focus,.lst-cas>h6 a:hover,.ltst-prd-inf>h6 a:focus,.ltst-prd-inf>h6 a:hover,.pagination .page-link.active,.post-inf>a:focus,.post-inf>a:hover,.post-inf>h5 a:focus,.post-inf>h5 a:hover,.post-info>a,.prayer-timings>table tr:hover td,.product-detail-tabs>ul li a.nav-link.active,.product-detail-tabs>ul li a.nav-link:focus,.product-detail-tabs>ul li a.nav-link:hover,.product-inf>h5 a:focus,.product-inf>h5 a:hover,.pst-mta>li a:focus,.pst-mta>li a:hover,.rcnt-inf>h6 a:focus,.rcnt-inf>h6 a:hover,.rsnp-mnu ul li.menu-item-has-children.active:before,.rsnp-mnu ul>li.active>a,.rsnp-mnu ul>li:hover>a,.rsnp-mnu ul>li>a:focus,.rspn-cnt>span a:focus,.rspn-cnt>span a:hover,.rspn-srch>button:hover,.scl1>a:focus,.scl1>a:hover,.serv-bx:hover>i.green-clr,.service-detail-nav>ul li.active>a,.service-detail-nav>ul li:hover>a,.service-detail-nav>ul li>a:focus,.srch-btn:focus,.srch-btn:hover,.style1 nav>div ul ul li a:hover,.tag-clouds>a:focus,.tag-clouds>a:hover,.tch-dwn-btn>a:focus,.tch-dwn-btn>a:hover,.tch-thmb>a:focus,.tch-thmb>a:hover,.theme-clr,.time-box>span:first-child,.tp-lnks>li a:focus,.tp-lnks>li a:hover,.widget .srch-frm button i,.widget table a,.widget ul li>a:focus,.widget ul li>a:hover,.widget>div>ul li span.rss-date,.widget>div>ul li:before,.widget>h5+div>ul li:before,.widget>h5+div>ul li:hover>a,.widget>h5+div>ul li>a:focus,.widget>ul li span.rss-date,.widget>ul li:before,.widget_recent_comments a:hover,.woocommerce .star-rating span,.woocommerce .star-rating+a,.woocommerce .star-rating::before,.woocommerce .woocommerce-tabs ul.tabs li.active .star-rating span,.woocommerce .woocommerce-tabs ul.tabs li.active .star-rating::before,.woocommerce .woocommerce-tabs ul.tabs li:hover .star-rating span,.woocommerce .woocommerce-tabs ul.tabs li:hover .star-rating::before,.woocommerce div.product .woocommerce-tabs ul.tabs li a:focus,.woocommerce div.product .woocommerce-tabs ul.tabs li a:hover,.woocommerce div.product .woocommerce-tabs ul.tabs li.active a,.woocommerce div.product .woocommerce-tabs ul.tabs li.active>a,.woocommerce div.product .woocommerce-tabs ul.tabs li>a:focus,.woocommerce div.product .woocommerce-tabs ul.tabs li>a:hover,.woocommerce div.product form.cart .group_table td label a:focus,.woocommerce div.product form.cart .group_table td label a:hover,.woocommerce div.product form.cart .group_table td.woocommerce-grouped-product-list-item__price>span,.woocommerce div.product p.price,.woocommerce div.product span.price,.woocommerce form .form-row .required,.woocommerce form .form-row label abbr,.woocommerce form .form-row.woocommerce-invalid label,.woocommerce table.shop_table td.product-name a:focus,.woocommerce table.shop_table td.product-name a:hover,.woocommerce table.shop_table td.product-price,.woocommerce table.shop_table td.product-subtotal,.woocommerce ul.product_list_widget li a+del+ins,.woocommerce ul.product_list_widget li a:focus img+span.product-title,.woocommerce ul.product_list_widget li:hover img+span.product-title,.woocommerce ul.products li.product .price,.woocommerce-MyAccount-content p a,.woocommerce-MyAccount-navigation>ul>li a:focus,.woocommerce-MyAccount-navigation>ul>li a:hover,.woocommerce-MyAccount-navigation>ul>li.is-active a,.woocommerce-account .addresses .title .edit,.woocommerce-info a,.woocommerce-info::before,.woocommerce-message a,.woocommerce-message::before,.wp-block-calendar table#wp-calendar tbody a,.wp-block-calendar table#wp-calendar tfoot a,a:hover,body .pst-shr-tgs .tag-clouds a:hover,dd a,div.category-sticky .post-bx .post-inf::before,div.post-bx.lst .post-inf>a:focus,div.post-bx.lst .post-inf>a:hover,div.sticky .post-bx .post-inf::before,div.tag-sticky-2 .post-bx .post-inf::before,dl a,form.cart+a.compare:focus,form.cart+a.compare:hover,h2+table td a,h2+table th a,header.style1 .scl1>a:focus,header.style1 .scl1>a:hover,header.style1 nav>div>a.srch-btn:focus,header.style1 nav>div>a.srch-btn:hover,nav>div>ul li a:focus,nav>div>ul li:hover,nav>div>ul li:hover>a,nav>div>ul>li.menu-item-has-children:hover:after,ol.breadcrumb>li.breadcrumb-item.active,p a,table th a:focus,table th a:hover, header.style2 .dropdown-menu, .tq-service-box2 i, footer span a:hover, .widget a:hover, .tq-header-menu nav ul ul li.menu-item-has-children > a:hover, .single .event-detail-desc > ul li:before, .single-campaign .cause-detail-wrp .scl1 > a:hover
		{
			color:#DB9E30; 
		}.abt-vdo.style2:before,.dnt-lst>a:focus,.dnt-lst>a:hover,.pagination>li.active,.pagination>li:hover,.product-detail-tabs>ul li a.nav-link.active,.product-detail-tabs>ul li a.nav-link:focus,.product-detail-tabs>ul li a.nav-link:hover,.serv-bx2:hover .serv-inf2,.theme-brd-clr,.wp-block-button .wp-block-button__link:focus,.wp-block-button .wp-block-button__link:hover,li.pr-tm-bx
		{
			border-color: #DB9E30;
		}.testi-desc
		{
			border-top-color: #DB9E30;
		}#add_payment_method .wc-proceed-to-checkout a.checkout-button:focus,#add_payment_method .wc-proceed-to-checkout a.checkout-button:hover,.blue-bg,.btn-primary:hover,.cont-frm .form-submit input:focus,.cont-frm .form-submit input:hover,.cont-frm input.wpcf7-submit:focus,.cont-frm input.wpcf7-submit:hover,.dnt-lst a.brd-rd30.active,.em-booking-buttons input[type=submit]:focus,.em-booking-buttons input[type=submit]:hover,.em-booking-login-form>input[type=submit]:focus,.em-booking-login-form>input[type=submit]:hover,.fea-prd-prc:before,.featured-area-wrap .owl-carousel button.owl-dot,.green-bg,.green-bg-layer:before,.lg-mnu-inr,.lg-mnu-sec,.lgn-rgstr-frm input[type=submit]:focus,.lgn-rgstr-frm input[type=submit]:hover,.namaz-drp .table thead>tr,.owl-carousel .owl-nav>button:focus,.owl-carousel .owl-nav>button:hover,.package-box.active:before,.post-password-form input[type=submit]:focus,.post-password-form input[type=submit]:hover,.rcnt-pst:before,.rspn-mnu-btn,.serv-bx:hover .srv-inf.theme-bg,.single-product .btn-primary:hover,.tagcloud>a:focus,.tagcloud>a:hover,.theme-bg .newsletter-form form p:last-of-type input,.theme-bg .newsletter-form>button,.theme-btn.theme-bg:after,.theme-btn.theme-bg:before,.widget.blue-bg2.style2,.woocommerce #respond input#submit.alt:focus,.woocommerce #respond input#submit.alt:hover,.woocommerce #respond input#submit:focus,.woocommerce #respond input#submit:hover,.woocommerce .cart .button:focus,.woocommerce .cart .button:hover,.woocommerce .cart input.button:focus,.woocommerce .cart input.button:hover,.woocommerce .woocommerce-error .button:focus,.woocommerce .woocommerce-error .button:hover,.woocommerce .woocommerce-info .button:focus,.woocommerce .woocommerce-info .button:hover,.woocommerce .woocommerce-message .button:focus,.woocommerce .woocommerce-message .button:hover,.woocommerce a.button.alt:focus,.woocommerce a.button.alt:hover,.woocommerce a.button:focus,.woocommerce a.button:hover,.woocommerce a.remove:focus,.woocommerce a.remove:hover,.woocommerce button.button.alt:focus,.woocommerce button.button.alt:hover,.woocommerce button.button:focus,.woocommerce button.button:hover,.woocommerce div.product form.cart .button:focus,.woocommerce div.product form.cart .button:hover,.woocommerce input.button.alt:focus,.woocommerce input.button.alt:hover,.woocommerce input.button:focus,.woocommerce input.button:hover,.woocommerce ul.products li.product a:focus,.woocommerce ul.products li.product a:hover,.woocommerce-cart .wc-proceed-to-checkout a.checkout-button:focus,.woocommerce-cart .wc-proceed-to-checkout a.checkout-button:hover,.woocommerce-checkout .wc-proceed-to-checkout a.checkout-button:focus,.woocommerce-checkout .wc-proceed-to-checkout a.checkout-button:hover,.woocommerce-page .woocommerce-error .button:focus,.woocommerce-page .woocommerce-error .button:hover,.woocommerce-page .woocommerce-info .button:focus,.woocommerce-page .woocommerce-info .button:hover,.woocommerce-page .woocommerce-message .button:focus,.woocommerce-page .woocommerce-message .button:hover,.wp-block-tag-cloud>a:focus,.wp-block-tag-cloud>a:hover,footer .wpcf7 input[type=submit]:hover,form.wp-block-search button:focus,form.wp-block-search button:hover,header.style2>.topbar,input.mailpoet_submit, .namaz-drp button#dropdownMenuButton
		{
			background-color: #004B39;
		}.error-page-inner>h1,.error-page-inner>p a:focus,.error-page-inner>p a:hover,.error-page-inner>span,.green-clr,.inf-lst li,.menu-sec nav>div>ul>li:hover>a,.menu-sec nav>div>ul>li>a:focus,.pr-tm-bx>span i,.rspn-cnt .inf-lst>li i,.serv-bx:hover>i.theme-clr,.serv-bx>h5 a:focus,.serv-bx>h5 a:hover,.style2 nav>div ul li:hover,.woocommerce a.button.alt:hover,.woocommerce a.button:hover,.woocommerce button.button.alt:hover,.woocommerce button.button:hover,.woocommerce div.product p.price,.woocommerce div.product span.price,.woocommerce-MyAccount-content p a:focus,.woocommerce-MyAccount-content p a:hover,.woocommerce-account .addresses .title .edit:focus,.woocommerce-account .addresses .title .edit:hover,.woocommerce-page a.button.alt:hover,.woocommerce-page a.button:hover,.woocommerce-page button.button.alt:hover,.woocommerce-page button.button:hover, a.comment-reply-link:hover, p a:hover, #cancel-comment-reply-link:hover, .widget .srch-frm button i:hover, .cmt-inf a.url:hover
		{
			color: #004B39 !important;
		}.green-brd-clr, .namaz-drp button#dropdownMenuButton
		{
			border-color: #004B39;
		}</style><style id="charitable-highlight-colour-styles">.campaign-raised .amount,.campaign-figures .amount,.donors-count,.time-left,.charitable-form-field a:not(.button),.charitable-form-fields .charitable-fieldset a:not(.button),.charitable-notice,.charitable-notice .errors a {color:;}#charitable-donation-form .charitable-notice {border-color:;}.campaign-progress-bar .bar,.donate-button,.charitable-donation-form .donation-amount.selected,.charitable-donation-amount-form .donation-amount.selected { background-color:#f89d35; }.charitable-donation-form .donation-amount.selected,.charitable-donation-amount-form .donation-amount.selected,.charitable-notice,.charitable-drag-drop-images li:hover a.remove-image,.supports-drag-drop .charitable-drag-drop-dropzone.drag-over { border-color:#f89d35; }</style><meta name="generator" content="Elementor 3.27.6; features: additional_custom_breakpoints; settings: css_print_method-external, google_font-enabled, font_display-auto">
			<style>
				.e-con.e-parent:nth-of-type(n+4):not(.e-lazyloaded):not(.e-no-lazyload),
				.e-con.e-parent:nth-of-type(n+4):not(.e-lazyloaded):not(.e-no-lazyload) * {
					background-image: none !important;
				}
				@media screen and (max-height: 1024px) {
					.e-con.e-parent:nth-of-type(n+3):not(.e-lazyloaded):not(.e-no-lazyload),
					.e-con.e-parent:nth-of-type(n+3):not(.e-lazyloaded):not(.e-no-lazyload) * {
						background-image: none !important;
					}
				}
				@media screen and (max-height: 640px) {
					.e-con.e-parent:nth-of-type(n+2):not(.e-lazyloaded):not(.e-no-lazyload),
					.e-con.e-parent:nth-of-type(n+2):not(.e-lazyloaded):not(.e-no-lazyload) * {
						background-image: none !important;
					}
				}
			</style>
			<link rel="icon" href="https://naudummy.com/muezzin/wp-content/uploads/2023/12/cropped-favicon-32x32.png" sizes="32x32" />
<link rel="icon" href="https://naudummy.com/muezzin/wp-content/uploads/2023/12/cropped-favicon-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://naudummy.com/muezzin/wp-content/uploads/2023/12/cropped-favicon-180x180.png" />
<meta name="msapplication-TileImage" content="https://naudummy.com/muezzin/wp-content/uploads/2023/12/cropped-favicon-270x270.png" />
<style id="taqwa_options-dynamic-css" title="dynamic-css" class="redux-options-output">body h1{font-family:"Cinzel Decorative";font-weight:700;font-style:normal;color:#000;font-size:60px;}body h2{font-family:"Cinzel Decorative";font-weight:700;font-style:normal;color:#000;font-size:54px;}body h3{font-family:"Cinzel Decorative";font-weight:700;font-style:normal;color:#000;font-size:30px;}body h4{font-family:"Cinzel Decorative";font-weight:700;font-style:normal;color:#000;font-size:26px;}body h5 {font-family:"Cinzel Decorative";font-weight:700;font-style:normal;color:#000;font-size:24px;}body h6 {font-family:Epilogue;font-weight:700;font-style:normal;color:#fff;font-size:16px;}body p, .event-detail-desc > p, .inf-lst li, .hdr-srch > form input, .pst-mta li, .post-inf > a, .post-bx .post-inf > p, .widget form input, .widget form textarea, .cpy-rgt > p, .pagination > li, .wp-block-button .wp-block-button__link, .wp-block-cover p.wp-block-cover-text, body ol li, body .elementor-text-editor p:not(:first-child), body ul li, figcaption, .elementor-text-editor p:not(:first-child){font-family:Epilogue;font-weight:400;font-style:normal;color:#444;font-size:16px;}#nav-id li a, .menu-sec nav > div > ul > li, .tq-header-menu nav ul li, .tq-header-menu nav ul ul li{font-family:Epilogue;font-weight:600;font-style:normal;color:#fff;font-size:16px;}html body, .tag-clouds > span, .tag-clouds > a, .pst-shr-tgs .scl1, .single-campaign .tag-clouds, .theme-btn, .cause-detail-inf-inr .pst-mta > li span, .event-detail-desc ul li:not(.blocks-gallery-grid .blocks-gallery-image, .blocks-gallery-grid .blocks-gallery-item, .wp-block-gallery .blocks-gallery-image, .wp-block-gallery .blocks-gallery-item){font-family:Epilogue;font-weight:normal;font-style:normal;}</style></head>

<body class="error404 elementor-default elementor-kit-5" itemscope>

    	
	<!--Wrapper Start-->
	<main>
				
		<header class="stick tq-style1">
            <div class="container">
                <div class="tq-header-wrapper position-relative w-100">
                    <div class="row">
                        <div class="col-md-2 col-sm-3 col-lg-2">
                            <div class="tq-logo position-relative w-100">
                                <a href="https://naudummy.com/muezzin/">
<svg class="fill-theme"
	xmlns="http://www.w3.org/2000/svg" viewBox="0 0 184.15 191.11">
	<g>
		<path d="M93.08,191.11c-0.33,0-0.67,0-1,0c-5.44-8.58-13.89-13.21-22.85-16.97c-9.31-3.91-17.25-9.39-22.27-18.33
	c-1.76-3.14-3.91-4.36-7.49-4.54C27.15,150.68,20,144.64,17,132.6c-0.51-2.04-1.41-3.36-3.43-3.73c-5.72-1.05-9.92-4.41-13.5-8.75
	C0.08,81.49,0.12,42.87,0,4.25C-0.01,1.13,0.22-0.01,3.93,0c58.76,0.16,117.53,0.16,176.29,0c3.71-0.01,3.94,1.13,3.93,4.25
	c-0.12,38.29-0.08,76.58-0.08,114.86c-3.3,4.84-7.56,8.35-13.42,9.66c-2.18,0.49-3.38,1.86-3.81,4.08
	c-2.43,12.48-11.13,17.35-22.76,18.52c-2.09,0.21-4,0.61-5.04,2.62c-5.68,11.04-15.46,16.87-26.43,21.58
	C104.81,178.91,97.44,183.23,93.08,191.11z" />
	</g>
</svg>
									<img src="https://naudummy.com/muezzin/wp-content/uploads/2024/01/logo-insignia.png" alt="" loading="lazy">
								</a>
                            </div><!-- Logo -->
                        </div>
                        <div class="col-md-10 col-sm-9 col-lg-10">
                            <div class="tq-header-inner d-flex flex-column position-relative w-100">
                                <div
                                    class="tq-header-topbar d-flex flex-wrap justify-content-between position-relative w-100">
                                    <ul
                                        class="tq-top-links text-white d-inline-flex align-items-center list-unstyled mb-0">
                                        											<li>
<svg class="fill-white" xmlns="http://www.w3.org/2000/svg"
	viewBox="0 0 100 100">
	<g>
		<path d="M72.64,97.5c-15.09,0-30.18,0-45.27,0c-0.26-0.1-0.52-0.21-0.78-0.29c-2.64-0.78-4.54-2.44-5.74-4.9
	c-0.78-1.6-0.92-3.32-0.92-5.06c0-12.31,0-24.62,0-36.92c0-12.68,0-25.36,0-38.04c0-2.6,0.7-4.93,2.46-6.9
	c1.35-1.51,3.1-2.31,4.99-2.88c15.09,0,30.18,0,45.27,0c0.26,0.1,0.52,0.21,0.78,0.29c2.65,0.78,4.53,2.46,5.74,4.91
	c0.77,1.56,0.92,3.26,0.92,4.97c0,9.34,0,18.68,0,28.02c0,15.58,0,31.17,0,46.75c0,2.68-0.59,5.14-2.46,7.18
	C76.26,96.11,74.53,96.93,72.64,97.5z M72.63,47.49C72.63,47.49,72.63,47.49,72.63,47.49c0.01-3.53,0.01-7.05,0.01-10.58
	c0-5.94-0.05-11.87,0.02-17.81c0.04-3.51-2.48-6.12-5.82-6.13c-11.22-0.03-22.45-0.02-33.67,0c-1.93,0-3.53,0.81-4.71,2.38
	c-0.97,1.29-1.1,2.77-1.1,4.31c0.01,18.49,0.01,36.98,0.01,55.47c0,0.43,0.01,0.87,0.03,1.3c0.17,3.06,2.55,5.4,5.63,5.41
	c11.32,0.03,22.64,0.01,33.95,0.01c0.88,0,1.72-0.21,2.5-0.62c2.25-1.2,3.18-3.12,3.17-5.64C72.6,66.22,72.63,56.86,72.63,47.49z
	 M49.97,91.29c1.15,0.02,2.33-1.14,2.36-2.3c0.02-1.16-1.13-2.33-2.3-2.35c-1.16-0.02-2.33,1.12-2.36,2.29
	C47.65,90.08,48.81,91.26,49.97,91.29z" />
	</g>
</svg>
													
													Call Us: <a href="tel:+(00) 123-345-11"
														title="Call Us">+(00) 123-345-11</a>
												</li>
																				
																					<li>
<svg class="fill-white" xmlns="http://www.w3.org/2000/svg"
	viewBox="0 0 100 100">
	<g>
		<path d="M53.32,2.5c2.47,0.39,4.95,0.76,7.31,1.64C73.44,8.93,81.14,18.06,83.15,31.6c1.33,8.92-0.98,17.12-6.37,24.38
	c-5.87,7.89-11.77,15.75-17.69,23.6c-4.7,6.23-13.52,6.23-18.22,0c-5.92-7.85-11.82-15.72-17.69-23.59
	c-5.01-6.72-7.15-14.3-6.62-22.64c0.88-13.63,10.92-25.92,24.1-29.63c1.97-0.55,3.98-0.86,5.98-1.22C48.86,2.5,51.09,2.5,53.32,2.5
	z M24.08,35.06c0.1,6.6,1.76,11.76,5.17,16.31c5.85,7.82,11.72,15.64,17.58,23.45c1.81,2.41,4.47,2.43,6.27,0.03
	c5.89-7.83,11.79-15.66,17.63-23.53c4.36-5.88,5.91-12.52,4.74-19.72C73.25,17.81,60.22,8.37,46.35,10.29
	C34.65,11.91,24.22,21.92,24.08,35.06z" />
		<path
			d="M34.02,97.5c-1.63-0.76-2.72-1.9-2.66-3.85c0.05-1.97,1.62-3.62,3.6-3.63c10.01-0.02,20.03-0.02,30.04,0
	c1.59,0,2.97,1.1,3.45,2.63c0.5,1.6-0.08,3.29-1.47,4.26c-0.33,0.23-0.7,0.4-1.04,0.59C55.3,97.5,44.66,97.5,34.02,97.5z" />
		<path d="M49.99,47.1c-6.24,0-11.2-4.94-11.21-11.17c0-6.29,4.94-11.23,11.23-11.23c6.22,0.01,11.16,4.97,11.16,11.21
	C61.17,42.14,56.22,47.09,49.99,47.1z M50,32.27c-1.92-0.02-3.63,1.67-3.65,3.61c-0.02,1.92,1.67,3.63,3.61,3.65
	c1.92,0.02,3.63-1.67,3.65-3.61C53.62,33.99,51.94,32.29,50,32.27z" />
	</g>
</svg>
												New Orleans, Jamia Mosque											</li>
										                                    </ul><!-- Top Links -->
                                    <div class="tq-social-links text-white d-inline-flex align-items-center">
                                        
								<a href="https://twitter.com" title="" itemprop="url" target="_blank"><i class="fab fa-twitter"></i></a>
								<a href="https://facebook.com" title="" itemprop="url" target="_blank"><i class="fab fa-facebook-f"></i></a>
				
					<a href="https://linkedin.com" title="" itemprop="url" target="_blank"><i class="fab fa-linkedin-in"></i></a>
							<a href="https://instagram.com" title="" itemprop="url" target="_blank"><i class="fab fa-instagram"></i></a>
			                                    </div><!-- Social Links -->
                                </div><!-- Header Topbar -->
                                <div
                                    class="tq-header-menu d-flex align-items-center justify-content-between position-relative w-100">
                                    <nav>
                                        <ul id="menu-main-menu" class=""><li id="menu-item-635" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-635"><a>Home</a>
<ul class="sub-menu">
	<li id="menu-item-2332" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-2332"><a href="https://naudummy.com/muezzin/">Home – Style 1</a></li>
	<li id="menu-item-2969" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2969"><a href="https://naudummy.com/muezzin/islamic/">Home – Style 2</a></li>
</ul>
</li>
<li id="menu-item-693" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-693"><a>Charity</a>
<ul class="sub-menu">
	<li id="menu-item-707" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-707"><a href="https://naudummy.com/muezzin/our-campaigns/">Our Campaigns</a></li>
	<li id="menu-item-783" class="menu-item menu-item-type-post_type menu-item-object-campaign menu-item-783"><a href="https://naudummy.com/muezzin/campaigns/educate-rural-kenya/">Campaign Details</a></li>
</ul>
</li>
<li id="menu-item-724" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-724"><a href="#">Events</a>
<ul class="sub-menu">
	<li id="menu-item-723" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-723"><a href="https://naudummy.com/muezzin/upcoming-events/">Our Events</a></li>
	<li id="menu-item-2038" class="menu-item menu-item-type-post_type menu-item-object-event menu-item-2038"><a href="https://naudummy.com/muezzin/events/intl-hajj-program-offers/">Intl. Hajj Program Offers</a></li>
</ul>
</li>
<li id="menu-item-630" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-630"><a>Scholars</a>
<ul class="sub-menu">
	<li id="menu-item-671" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-671"><a href="https://naudummy.com/muezzin/islamic-scholars/">Islamic Scholars</a></li>
	<li id="menu-item-796" class="menu-item menu-item-type-post_type menu-item-object-team menu-item-796"><a href="https://naudummy.com/muezzin/team/sharif-hammam/">Scholar Profile</a></li>
</ul>
</li>
<li id="menu-item-628" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-628"><a>Pages</a>
<ul class="sub-menu">
	<li id="menu-item-972" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-972"><a href="https://naudummy.com/muezzin/about-us/">About Us</a></li>
	<li id="menu-item-3366" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3366"><a href="https://naudummy.com/muezzin/online-classes/">Online Classes</a></li>
	<li id="menu-item-3375" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3375"><a href="https://naudummy.com/muezzin/travel-tours/">Travel &#038; Tours</a></li>
	<li id="menu-item-632" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-632"><a>Services</a>
	<ul class="sub-menu">
		<li id="menu-item-673" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-673"><a href="https://naudummy.com/muezzin/offered-services/">Offered Services</a></li>
		<li id="menu-item-801" class="menu-item menu-item-type-post_type menu-item-object-services menu-item-801"><a href="https://naudummy.com/muezzin/services/hajj-umrah/">Service Details</a></li>
	</ul>
</li>
	<li id="menu-item-689" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-689"><a>Blog Posts</a>
	<ul class="sub-menu">
		<li id="menu-item-703" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-703"><a href="https://naudummy.com/muezzin/latest-blog/">Blog Style &#8211; List</a></li>
		<li id="menu-item-702" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-702"><a href="https://naudummy.com/muezzin/grid-blog-posts/">Blog Style &#8211; Grid</a></li>
		<li id="menu-item-790" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-790"><a href="https://naudummy.com/muezzin/is-islam-a-modern-philosophy/">Blog Details</a></li>
	</ul>
</li>
	<li id="menu-item-2114" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2114"><a href="https://naudummy.com/muezzin/audios/">Audio Sermons</a></li>
	<li id="menu-item-3433" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3433"><a href="https://naudummy.com/muezzin/salat-timings/">Salat Timings</a></li>
	<li id="menu-item-675" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-675"><a href="https://naudummy.com/muezzin/islamic-teachings/">Islamic Teachings</a></li>
	<li id="menu-item-3451" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-3451"><a href="https://naudummy.com/muezzin/category/blog-list/">Most Searched</a></li>
</ul>
</li>
<li id="menu-item-674" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-674"><a href="https://naudummy.com/muezzin/contact-us/">Contact</a></li>
</ul> 
                                    </nav><!-- Navigation -->
                                    <div class="tq-header-menu-right d-inline-flex align-items-center">
                                        <!-- Side Menu -->
										<a class="tq-menu-btn" href="">
											<span>
												<i class="tq-bar-top"></i>
												<i class="tq-bar-middle"></i>
												<i class="tq-bar-bottom"></i>
											</span>
										</a>
										<!-- Side Menu Ends -->
                                        <div class="tq-select-box position-relative tq-bg-theme rounded-pill">
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">
	<path
		d="M50,86.11c-19.91,0-36.11-16.2-36.11-36.12S30.09,13.89,50,13.89c19.91,0,36.12,16.2,36.12,36.11
	c0,1.68-1.36,3.04-3.04,3.04c-1.68,0-3.04-1.36-3.04-3.04c0-16.56-13.48-30.03-30.04-30.03S19.97,33.44,19.97,50
	S33.44,80.03,50,80.03c1.68,0,3.04,1.36,3.04,3.04C53.04,84.75,51.68,86.11,50,86.11z" />
	<path
		d="M50,97.5C23.81,97.5,2.5,76.19,2.5,50S23.81,2.5,50,2.5S97.5,23.81,97.5,50C97.5,76.19,76.19,97.5,50,97.5z M50,8.58
	C27.16,8.58,8.58,27.16,8.58,50S27.16,91.42,50,91.42S91.42,72.84,91.42,50S72.84,8.58,50,8.58z" />
	<path
		d="M63.22,66.26c-0.78,0-1.55-0.3-2.15-0.89L47.85,52.15c-0.57-0.57-0.89-1.35-0.89-2.15V28.58c0-1.68,1.36-3.04,3.04-3.04
	c1.68,0,3.04,1.36,3.04,3.04v20.16l12.33,12.32c1.19,1.19,1.19,3.11,0,4.3C64.77,65.96,64,66.26,63.22,66.26z" />
</svg>
                                            <div class="dropdown">
                                                <button class="btn dropdown-toggle" type="button"
                                                    data-bs-toggle="dropdown">
                                                    Namaz Timings                                                </button>
                                                <div class="dropdown-menu">
                                                    
			  <table class="table table-borderless jamat-time">
				  <thead>
					<tr>
					  <th scope="col">Namaz</th>
					  <th scope="col">Time</th>
					  <th scope="col">Iqamah</th>
					</tr>
				  </thead>
				  <tbody>
					<tr>
					  <td><i class="fa fa-sun-o" aria-hidden="true"></i>Fajr</td>
					  <td>3:43 AM</td>
					  <td>5:00 AM</td>
					</tr>
					<tr>
					  <td><i class="fa fa-sun-o" aria-hidden="true"></i>Zuhr</td>
					  <td>01:03 PM</td>
					  <td>1:30 PM</td>
					</tr>
					<tr>
					  <td><i class="fa fa-sun-o" aria-hidden="true"></i>Asr</td>
					  <td>5:55 PM</td>
					  <td>6:30 PM</td>
					</tr>
					<tr>
					  <td><i class="fa fa-moon-o" aria-hidden="true"></i>Magrib</td>
					  <td>8:17 PM</td>
					  <td>8:17 PM</td>
					</tr>
					<tr>
					  <td><i class="fa fa-moon-o" aria-hidden="true"></i>Isha</td>
					  <td>9:22 PM</td>
					  <td>9:45 PM
</td>
					</tr>
				  </tbody>
				</table>
			</div>                                                </div>
                                            </div>
                                        </div><!-- Header Menu Right -->
                                    </div><!-- Header Menu -->
                                </div><!-- Header Inner -->
                            </div>
                        </div>
                    </div><!-- Header Wrapper -->
                </div>
        </header><!-- Header -->
		
		<div class="tq-side-menu d-flex flex-column align-items-start position-fixed w-100">
            <a class="tq-side-menu-close" href="javascript:void(0);"><i class="fas fa-times"></i></a>
            <div class="tq-logo v2 position-relative w-100"><a href="https://naudummy.com/muezzin/">
<svg class="fill-theme"
	xmlns="http://www.w3.org/2000/svg" viewBox="0 0 184 281">
	<g>
		<path
			d="M184,72c0,45.67,0,91.33,0,137c-3.3,4.84-7.56,8.35-13.42,9.66c-2.18,0.49-3.38,1.86-3.81,4.08
			c-2.43,12.48-11.13,17.35-22.76,18.52c-2.09,0.21-4.01,0.61-5.04,2.62c-5.68,11.04-15.46,16.87-26.43,21.58
			C104.74,268.8,97.36,273.12,93,281c-0.33,0-0.67,0-1,0c-5.44-8.58-13.89-13.21-22.85-16.97c-9.31-3.91-17.25-9.39-22.27-18.33
			c-1.76-3.14-3.91-4.36-7.49-4.54c-12.32-0.6-19.47-6.63-22.47-18.67c-0.51-2.04-1.41-3.36-3.43-3.73C7.77,217.7,3.57,214.35,0,210
			c0-46.33,0-92.67,0-139c3.57-4.35,7.77-7.7,13.5-8.76c1.75-0.32,2.78-1.38,3.34-3.24c4.15-13.84,9.21-17.89,24.05-19.28
			c2.14-0.2,3.87-0.73,4.93-2.74c5.5-10.43,14.54-16.43,25.15-20.84C79.31,12.67,87,8,92,0c0.33,0,0.67,0,1,0
			c5.02,8.78,13.53,13.02,22.26,16.8c9.55,4.14,17.87,9.63,22.88,19.07c1.53,2.88,3.8,3.71,6.87,3.97
			c11.74,1.01,18.55,6.68,21.6,17.95c0.69,2.54,1.86,4.14,4.45,4.71C176.75,63.77,180.78,67.35,184,72z" />
	</g>
</svg>
					<img class="img-fluid position-absolute" src="https://naudummy.com/muezzin/wp-content/uploads/2024/01/logo-insignia.png" loading="lazy"></a>
            </div>
            <!-- Logo -->
            <div class="tq-widget-box d-flex flex-column position-relative w-100">
                <h4 class="mb-0">Information</h4>
                <p class="mb-0">Elit duis volutpat ligula nulla a getmolestie mi consectetur auctor
                    ugue ac tincidunt, var ius felis et, augue lorem. Aliquam accumsan fringilla.                </p>
            </div><!-- Widget Box -->
            <div class="tq-widget-box d-flex flex-column position-relative w-100">
                <h4 class="mb-0">Contact Info</h4>
                <ul class="tq-cont-list d-flex flex-column list-unstyled w-100">
                    <li><i class="tq-bg-theme d-inline-flex align-items-center justify-content-center rounded-circle">
<svg
class="fill-white" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">
<g>
<path d="M72.64,97.5c-15.09,0-30.18,0-45.27,0c-0.26-0.1-0.52-0.21-0.78-0.29c-2.64-0.78-4.54-2.44-5.74-4.9
c-0.78-1.6-0.92-3.32-0.92-5.06c0-12.31,0-24.62,0-36.92c0-12.68,0-25.36,0-38.04c0-2.6,0.7-4.93,2.46-6.9
c1.35-1.51,3.1-2.31,4.99-2.88c15.09,0,30.18,0,45.27,0c0.26,0.1,0.52,0.21,0.78,0.29c2.65,0.78,4.53,2.46,5.74,4.91
c0.77,1.56,0.92,3.26,0.92,4.97c0,9.34,0,18.68,0,28.02c0,15.58,0,31.17,0,46.75c0,2.68-0.59,5.14-2.46,7.18
C76.26,96.11,74.53,96.93,72.64,97.5z M72.63,47.49C72.63,47.49,72.63,47.49,72.63,47.49c0.01-3.53,0.01-7.05,0.01-10.58
c0-5.94-0.05-11.87,0.02-17.81c0.04-3.51-2.48-6.12-5.82-6.13c-11.22-0.03-22.45-0.02-33.67,0c-1.93,0-3.53,0.81-4.71,2.38
c-0.97,1.29-1.1,2.77-1.1,4.31c0.01,18.49,0.01,36.98,0.01,55.47c0,0.43,0.01,0.87,0.03,1.3c0.17,3.06,2.55,5.4,5.63,5.41
c11.32,0.03,22.64,0.01,33.95,0.01c0.88,0,1.72-0.21,2.5-0.62c2.25-1.2,3.18-3.12,3.17-5.64C72.6,66.22,72.63,56.86,72.63,47.49z
	M49.97,91.29c1.15,0.02,2.33-1.14,2.36-2.3c0.02-1.16-1.13-2.33-2.3-2.35c-1.16-0.02-2.33,1.12-2.36,2.29
C47.65,90.08,48.81,91.26,49.97,91.29z">
</path>
</g>
</svg>
							</i>
                        <p class="mb-0">Call Us:                            <a href="tel:+(00) 123-345-11">+(00) 123-345-11</a><br> <span>Mon - Sat 8:00 - 18:00</span>
                        </p>
                    </li>
                    <li><i class="tq-bg-theme d-inline-flex align-items-center justify-content-center rounded-circle">
<svg
class="fill-white" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">
<g>
<path d="M97.5,67.79c-0.5,3.23-1.43,6.33-3.22,9.1c-4.41,6.78-10.62,10.54-18.75,10.59c-16.99,0.1-33.98,0.05-50.97,0.02
C13.58,87.48,4.11,79.1,2.69,68.23c-0.13-1.02-0.17-2.03-0.17-3.05c0-10.13,0.06-20.26-0.02-30.4
c-0.08-10.87,8.14-20.67,19.38-22.15c0.86-0.11,1.72-0.16,2.58-0.16c17.05,0,34.1-0.02,51.15,0.01
c10.79,0.02,20.23,8.3,21.74,18.98c0.03,0.24,0.09,0.48,0.14,0.72C97.5,44.06,97.5,55.92,97.5,67.79z M50.02,79.96
c8.22,0,16.44,0,24.65,0c1.05,0,2.1-0.08,3.13-0.28c7.28-1.41,12.19-7.33,12.21-14.77c0.03-9.95,0.01-19.9,0-29.84
c0-0.92-0.08-1.86-0.25-2.76c-1.37-7.28-7.3-12.26-14.71-12.27c-16.68-0.03-33.37-0.01-50.05,0c-0.92,0-1.85,0.1-2.76,0.28
c-7.2,1.41-12.13,7.28-12.16,14.61c-0.04,10.04-0.05,20.08,0.01,30.12c0.02,4.27,1.57,7.96,4.72,10.91c2.94,2.75,6.49,3.99,10.47,4
C33.52,79.97,41.77,79.96,50.02,79.96z" />
<path
d="M50.23,61.2c-5.05-0.03-9.57-1.47-13.53-4.5c-5.94-4.55-11.82-9.15-17.72-13.75c-1.85-1.44-2.19-3.78-0.85-5.48
c1.35-1.72,3.64-1.97,5.52-0.52c5.48,4.23,10.97,8.44,16.38,12.75c2.9,2.31,6.06,3.81,9.8,3.87c3.24,0.05,6.26-0.78,8.86-2.75
c6.07-4.57,12.09-9.21,18.13-13.82c0.85-0.65,1.71-1.2,2.85-1.17c1.6,0.03,2.97,0.91,3.56,2.36c0.58,1.44,0.29,3.12-0.94,4.16
c-1.75,1.47-3.59,2.83-5.41,4.22c-4.32,3.3-8.65,6.59-12.96,9.9C59.86,59.57,55.28,61.16,50.23,61.2z" />
</g>
</svg>
							</i><a href="mailto:info@example.com">info@example.com</a></li>
                    <li><i class="tq-bg-theme d-inline-flex align-items-center justify-content-center rounded-circle">
<svg
class="fill-white" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">
<g>
<path d="M53.32,2.5c2.47,0.39,4.95,0.76,7.31,1.64C73.44,8.93,81.14,18.06,83.15,31.6c1.33,8.92-0.98,17.12-6.37,24.38
c-5.87,7.89-11.77,15.75-17.69,23.6c-4.7,6.23-13.52,6.23-18.22,0c-5.92-7.85-11.82-15.72-17.69-23.59
c-5.01-6.72-7.15-14.3-6.62-22.64c0.88-13.63,10.92-25.92,24.1-29.63c1.97-0.55,3.98-0.86,5.98-1.22C48.86,2.5,51.09,2.5,53.32,2.5
z M24.08,35.06c0.1,6.6,1.76,11.76,5.17,16.31c5.85,7.82,11.72,15.64,17.58,23.45c1.81,2.41,4.47,2.43,6.27,0.03
c5.89-7.83,11.79-15.66,17.63-23.53c4.36-5.88,5.91-12.52,4.74-19.72C73.25,17.81,60.22,8.37,46.35,10.29
C34.65,11.91,24.22,21.92,24.08,35.06z">
</path>
<path
d="M34.02,97.5c-1.63-0.76-2.72-1.9-2.66-3.85c0.05-1.97,1.62-3.62,3.6-3.63c10.01-0.02,20.03-0.02,30.04,0
c1.59,0,2.97,1.1,3.45,2.63c0.5,1.6-0.08,3.29-1.47,4.26c-0.33,0.23-0.7,0.4-1.04,0.59C55.3,97.5,44.66,97.5,34.02,97.5z">
</path>
<path
d="M49.99,47.1c-6.24,0-11.2-4.94-11.21-11.17c0-6.29,4.94-11.23,11.23-11.23c6.22,0.01,11.16,4.97,11.16,11.21
C61.17,42.14,56.22,47.09,49.99,47.1z M50,32.27c-1.92-0.02-3.63,1.67-3.65,3.61c-0.02,1.92,1.67,3.63,3.61,3.65
c1.92,0.02,3.63-1.67,3.65-3.61C53.62,33.99,51.94,32.29,50,32.27z">
</path>
</g>
</svg>
							</i>New Orleans, Jamia Mosque</li>
                </ul><!-- Contact List -->
            </div><!-- Widget Box -->
        </div><!-- Side Menu -->
		
		<!-- Header Sticky -->
			
		<div class="tq-sticky-menu">
			<div class="container">
				<div class="tq-sticky-menu-inner d-flex flex-wrap align-items-center justify-content-between w-100">
					<div class="tq-logo position-relative w-100">
						<a href="https://naudummy.com/muezzin/"><svg class="fill-theme" xmlns="http://www.w3.org/2000/svg"
								viewBox="0 0 184.15 191.11">
								<g>
									<path d="M93.08,191.11c-0.33,0-0.67,0-1,0c-5.44-8.58-13.89-13.21-22.85-16.97c-9.31-3.91-17.25-9.39-22.27-18.33
									c-1.76-3.14-3.91-4.36-7.49-4.54C27.15,150.68,20,144.64,17,132.6c-0.51-2.04-1.41-3.36-3.43-3.73c-5.72-1.05-9.92-4.41-13.5-8.75
									C0.08,81.49,0.12,42.87,0,4.25C-0.01,1.13,0.22-0.01,3.93,0c58.76,0.16,117.53,0.16,176.29,0c3.71-0.01,3.94,1.13,3.93,4.25
									c-0.12,38.29-0.08,76.58-0.08,114.86c-3.3,4.84-7.56,8.35-13.42,9.66c-2.18,0.49-3.38,1.86-3.81,4.08
									c-2.43,12.48-11.13,17.35-22.76,18.52c-2.09,0.21-4,0.61-5.04,2.62c-5.68,11.04-15.46,16.87-26.43,21.58
									C104.81,178.91,97.44,183.23,93.08,191.11z" />
								</g>
							</svg><img src="https://naudummy.com/muezzin/wp-content/uploads/2024/01/logo-insignia.png" alt="" loading="lazy"></a>
					</div><!-- Logo -->
					<nav>
						<ul id="menu-main-menu-1" class=""><li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-635"><a>Home</a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-2332"><a href="https://naudummy.com/muezzin/">Home – Style 1</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2969"><a href="https://naudummy.com/muezzin/islamic/">Home – Style 2</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-693"><a>Charity</a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-707"><a href="https://naudummy.com/muezzin/our-campaigns/">Our Campaigns</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-campaign menu-item-783"><a href="https://naudummy.com/muezzin/campaigns/educate-rural-kenya/">Campaign Details</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-724"><a href="#">Events</a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-723"><a href="https://naudummy.com/muezzin/upcoming-events/">Our Events</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-event menu-item-2038"><a href="https://naudummy.com/muezzin/events/intl-hajj-program-offers/">Intl. Hajj Program Offers</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-630"><a>Scholars</a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-671"><a href="https://naudummy.com/muezzin/islamic-scholars/">Islamic Scholars</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-team menu-item-796"><a href="https://naudummy.com/muezzin/team/sharif-hammam/">Scholar Profile</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-628"><a>Pages</a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-972"><a href="https://naudummy.com/muezzin/about-us/">About Us</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3366"><a href="https://naudummy.com/muezzin/online-classes/">Online Classes</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3375"><a href="https://naudummy.com/muezzin/travel-tours/">Travel &#038; Tours</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-632"><a>Services</a>
	<ul class="sub-menu">
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-673"><a href="https://naudummy.com/muezzin/offered-services/">Offered Services</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-services menu-item-801"><a href="https://naudummy.com/muezzin/services/hajj-umrah/">Service Details</a></li>
	</ul>
</li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-689"><a>Blog Posts</a>
	<ul class="sub-menu">
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-703"><a href="https://naudummy.com/muezzin/latest-blog/">Blog Style &#8211; List</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-702"><a href="https://naudummy.com/muezzin/grid-blog-posts/">Blog Style &#8211; Grid</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-790"><a href="https://naudummy.com/muezzin/is-islam-a-modern-philosophy/">Blog Details</a></li>
	</ul>
</li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2114"><a href="https://naudummy.com/muezzin/audios/">Audio Sermons</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3433"><a href="https://naudummy.com/muezzin/salat-timings/">Salat Timings</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-675"><a href="https://naudummy.com/muezzin/islamic-teachings/">Islamic Teachings</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-3451"><a href="https://naudummy.com/muezzin/category/blog-list/">Most Searched</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-674"><a href="https://naudummy.com/muezzin/contact-us/">Contact</a></li>
</ul> 
					</nav>
				</div>
			</div>
		</div><!-- Sticky Header -->
			
				
		<div class="tq-res-header position-relative w-100">
            <div class="tq-res-topbar w-100">
                <div class="container">
                    <div class="tq-res-topbar-inner d-flex flex-wrap align-items-center justify-content-between w-100">
                        <div class="tq-logo position-relative w-100">
                            <a href="https://naudummy.com/muezzin/">
								<svg class="fill-theme" xmlns="http://www.w3.org/2000/svg"
                                    viewBox="0 0 184.15 191.11">
                                    <g>
                                        <path d="M93.08,191.11c-0.33,0-0.67,0-1,0c-5.44-8.58-13.89-13.21-22.85-16.97c-9.31-3.91-17.25-9.39-22.27-18.33
                                        c-1.76-3.14-3.91-4.36-7.49-4.54C27.15,150.68,20,144.64,17,132.6c-0.51-2.04-1.41-3.36-3.43-3.73c-5.72-1.05-9.92-4.41-13.5-8.75
                                        C0.08,81.49,0.12,42.87,0,4.25C-0.01,1.13,0.22-0.01,3.93,0c58.76,0.16,117.53,0.16,176.29,0c3.71-0.01,3.94,1.13,3.93,4.25
                                        c-0.12,38.29-0.08,76.58-0.08,114.86c-3.3,4.84-7.56,8.35-13.42,9.66c-2.18,0.49-3.38,1.86-3.81,4.08
                                        c-2.43,12.48-11.13,17.35-22.76,18.52c-2.09,0.21-4,0.61-5.04,2.62c-5.68,11.04-15.46,16.87-26.43,21.58
                                        C104.81,178.91,97.44,183.23,93.08,191.11z" />
                                    </g>
                                </svg>
		<img width="216" height="102" src="https://naudummy.com/muezzin/wp-content/themes/taqwa/assets/images/logo2.png" alt="Muezzin" itemprop="image">
								</a>
                        </div><!-- Logo -->
						
						<div class="tq-res-header-right d-inline-flex align-items-center">
                            <div class="tq-social-links text-white d-inline-flex align-items-center">
                                
								<a href="https://twitter.com" title="" itemprop="url" target="_blank"><i class="fab fa-twitter"></i></a>
								<a href="https://facebook.com" title="" itemprop="url" target="_blank"><i class="fab fa-facebook-f"></i></a>
				
					<a href="https://linkedin.com" title="" itemprop="url" target="_blank"><i class="fab fa-linkedin-in"></i></a>
							<a href="https://instagram.com" title="" itemprop="url" target="_blank"><i class="fab fa-instagram"></i></a>
			                            </div><!-- Social Links -->
                            <a class="tq-res-menu-trigger" href="javascript:void(0);" title=""><i
                                    class="fa fa-align-justify"></i></a>
                        </div><!-- Header Right -->
						
                        
                    </div><!-- Responsive Topbar Inner -->
                </div>
            </div><!-- Responsive Topbar -->
            <div class="tq-res-menu position-fixed w-100 rsnp-mnu">
                <a class="tq-res-menu-close position-absolute" href="javascript:void(0);"><i class="fa fa-times"></i></a>
                <ul id="menu-main-menu-2" class=""><li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-635"><a>Home</a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-2332"><a href="https://naudummy.com/muezzin/">Home – Style 1</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2969"><a href="https://naudummy.com/muezzin/islamic/">Home – Style 2</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-693"><a>Charity</a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-707"><a href="https://naudummy.com/muezzin/our-campaigns/">Our Campaigns</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-campaign menu-item-783"><a href="https://naudummy.com/muezzin/campaigns/educate-rural-kenya/">Campaign Details</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-724"><a href="#">Events</a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-723"><a href="https://naudummy.com/muezzin/upcoming-events/">Our Events</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-event menu-item-2038"><a href="https://naudummy.com/muezzin/events/intl-hajj-program-offers/">Intl. Hajj Program Offers</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-630"><a>Scholars</a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-671"><a href="https://naudummy.com/muezzin/islamic-scholars/">Islamic Scholars</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-team menu-item-796"><a href="https://naudummy.com/muezzin/team/sharif-hammam/">Scholar Profile</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-628"><a>Pages</a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-972"><a href="https://naudummy.com/muezzin/about-us/">About Us</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3366"><a href="https://naudummy.com/muezzin/online-classes/">Online Classes</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3375"><a href="https://naudummy.com/muezzin/travel-tours/">Travel &#038; Tours</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-632"><a>Services</a>
	<ul class="sub-menu">
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-673"><a href="https://naudummy.com/muezzin/offered-services/">Offered Services</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-services menu-item-801"><a href="https://naudummy.com/muezzin/services/hajj-umrah/">Service Details</a></li>
	</ul>
</li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-689"><a>Blog Posts</a>
	<ul class="sub-menu">
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-703"><a href="https://naudummy.com/muezzin/latest-blog/">Blog Style &#8211; List</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-702"><a href="https://naudummy.com/muezzin/grid-blog-posts/">Blog Style &#8211; Grid</a></li>
		<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-790"><a href="https://naudummy.com/muezzin/is-islam-a-modern-philosophy/">Blog Details</a></li>
	</ul>
</li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2114"><a href="https://naudummy.com/muezzin/audios/">Audio Sermons</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3433"><a href="https://naudummy.com/muezzin/salat-timings/">Salat Timings</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-675"><a href="https://naudummy.com/muezzin/islamic-teachings/">Islamic Teachings</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-3451"><a href="https://naudummy.com/muezzin/category/blog-list/">Most Searched</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-674"><a href="https://naudummy.com/muezzin/contact-us/">Contact</a></li>
</ul>            </div><!-- Responsive Menu -->
        </div><!-- Responsive Header -->
	
			
				<section>
            <div class="gap black-layer opc8 inner-banner">
                <div class="fixed-bg set-imagebloc" style="background-image: url(https://naudummy.com/muezzin/wp-content/uploads/2023/11/tq-feat-img2-2.jpg);"></div>
                <div class="container">
                    <div class="pg-tp-wrp text-center" style = "padding-top:50px">
                        <div class="pg-tp-inr">
																		<h1 itemprop="headline">404 Error Page</h1>
								   <ol class="breadcrumb brd-rd30"><li class="breadcrumb-item"><a href="https://naudummy.com/muezzin/">Home</a> </li> <li class="breadcrumb-item active">Error 404</li></ol>                        </div>
                    </div><!-- Page Top Wrap -->
                </div>
            </div>
        </section>
			
	<section>
		<div class="gap">
			<div class="container">
				<div class="error-page">
					<div class="error-page-inner">
						<h1 itemprop="headline">4<i class="theme-clr">0</i>4</h1>
						<span>Error! <span class="theme-clr">Page Not Found</span></span>
						<p itemprop="description">It seems we cant find what you are looking for. Perhaps searching can help or go <a class="theme-clr" href="https://naudummy.com/muezzin/" itemprop="url">Back To Hompage</a></p>
						<div class="search-form brd-rd30">
							<form method="get" class = "srch-frm" action="https://naudummy.com/muezzin/">
	<input name="s" type="text" required="" placeholder="Enter Your Keywords..." value="" onfocus="if (this.value = '') {this.value = '';}" onblur="if (this.value == '') {this.value = 'Enter Your Keywords...';}" >
	<button type="submit"><i class="fas fa-search"></i></button>
</form>						</div>
					</div>
				</div><!-- Error Page -->
			</div>
		</div>
	</section>
		
		
		<footer>
            <div class="w-100 tq-pt-100 tq-secondary-layer tq-opc1 tq-pb-30 overflow-hidden position-relative">
                						<div class="tq-fixed-bg tq-bg-secondary tq-bg-blend-multiply" style="background-image: url(https://naudummy.com/muezzin/wp-content/themes/taqwa/assets/images/tq-bg4.jpg);"></div>
				                <div class="container">
                    <div class="tq-footer-top d-flex align-items-center justify-content-between position-relative w-100">
                        <div class="tq-sec-title-wrapper tq-sec-title-left-icon mb-0 d-flex align-items-center justify-content-between position-relative w-100">
                            <div class="tq-sec-title d-flex flex-column">
																	<object class = "fill-theme position-absolute" data="https://naudummy.com/muezzin/wp-content/uploads/2023/12/footer-icon.svg" width="100" height="100"> </object>
																
																	<span>Become a Part of Our Community</span>
																
                                <h3 class="mb-0">Inspired? Join Us Right Now!</h3>
                            </div><!-- Section Title -->
                            								<a class="tq-theme-btn tq-bg-theme rounded-pill" href="https://naudummy.com/muezzin/contact-us/">Join Community</a>
							                        </div><!-- Section Title Wrapper -->
                    </div><!-- Footer Top -->
                    <div class="tq-footer-body position-relative w-100">
                        <div class="row">
                            							<div class="col-md-6 col-sm-6 col-lg-3">
                                <div class="tq-logo v2 position-relative"><a href="https://naudummy.com/muezzin/" title="">
<svg class="fill-theme" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 184 281">
	<g>
		<path d="M184,72c0,45.67,0,91.33,0,137c-3.3,4.84-7.56,8.35-13.42,9.66c-2.18,0.49-3.38,1.86-3.81,4.08
c-2.43,12.48-11.13,17.35-22.76,18.52c-2.09,0.21-4.01,0.61-5.04,2.62c-5.68,11.04-15.46,16.87-26.43,21.58
C104.74,268.8,97.36,273.12,93,281c-0.33,0-0.67,0-1,0c-5.44-8.58-13.89-13.21-22.85-16.97c-9.31-3.91-17.25-9.39-22.27-18.33
c-1.76-3.14-3.91-4.36-7.49-4.54c-12.32-0.6-19.47-6.63-22.47-18.67c-0.51-2.04-1.41-3.36-3.43-3.73C7.77,217.7,3.57,214.35,0,210
c0-46.33,0-92.67,0-139c3.57-4.35,7.77-7.7,13.5-8.76c1.75-0.32,2.78-1.38,3.34-3.24c4.15-13.84,9.21-17.89,24.05-19.28
c2.14-0.2,3.87-0.73,4.93-2.74c5.5-10.43,14.54-16.43,25.15-20.84C79.31,12.67,87,8,92,0c0.33,0,0.67,0,1,0
c5.02,8.78,13.53,13.02,22.26,16.8c9.55,4.14,17.87,9.63,22.88,19.07c1.53,2.88,3.8,3.71,6.87,3.97
c11.74,1.01,18.55,6.68,21.6,17.95c0.69,2.54,1.86,4.14,4.45,4.71C176.75,63.77,180.78,67.35,184,72z"></path>
	</g>
</svg>
									<img class="img-fluid position-absolute" src="https://naudummy.com/muezzin/wp-content/uploads/2024/01/logo-insignia.png" loading="lazy"></a>
								</div>
                                <!-- Logo -->
                            </div>
							                            
                            <div class="col-md-6 col-sm-6 col-lg-3"><div class="widget-box widget widget">
		
		<div class="tq-widget-box d-flex flex-column position-relative w-100">
			<h4 class="mb-0">Information</h4>
			<p class="mb-0">Elit duis volutpat ligula nulla a getmolestie mi consectetur auctor ugue ac tincidunt, var ius felis et, augue lorem. Aliquam accumsan fringilla.
			</p>
		</div></div></div><div class="col-md-6 col-sm-6 col-lg-3"><div class="widget-box widget widget"> 
			<div class="tq-widget-box d-flex flex-column position-relative w-100">
                                    <h4 class="mb-0">Contact Info</h4>
                                    <ul class="tq-cont-list d-flex flex-column list-unstyled w-100">
                                        <li><i class="tq-bg-theme d-inline-flex align-items-center justify-content-center rounded-circle">
<svg
	class="fill-white" xmlns="http://www.w3.org/2000/svg"
	viewBox="0 0 100 100">
	<g>
		<path d="M72.64,97.5c-15.09,0-30.18,0-45.27,0c-0.26-0.1-0.52-0.21-0.78-0.29c-2.64-0.78-4.54-2.44-5.74-4.9
			c-0.78-1.6-0.92-3.32-0.92-5.06c0-12.31,0-24.62,0-36.92c0-12.68,0-25.36,0-38.04c0-2.6,0.7-4.93,2.46-6.9
			c1.35-1.51,3.1-2.31,4.99-2.88c15.09,0,30.18,0,45.27,0c0.26,0.1,0.52,0.21,0.78,0.29c2.65,0.78,4.53,2.46,5.74,4.91
			c0.77,1.56,0.92,3.26,0.92,4.97c0,9.34,0,18.68,0,28.02c0,15.58,0,31.17,0,46.75c0,2.68-0.59,5.14-2.46,7.18
			C76.26,96.11,74.53,96.93,72.64,97.5z M72.63,47.49C72.63,47.49,72.63,47.49,72.63,47.49c0.01-3.53,0.01-7.05,0.01-10.58
			c0-5.94-0.05-11.87,0.02-17.81c0.04-3.51-2.48-6.12-5.82-6.13c-11.22-0.03-22.45-0.02-33.67,0c-1.93,0-3.53,0.81-4.71,2.38
			c-0.97,1.29-1.1,2.77-1.1,4.31c0.01,18.49,0.01,36.98,0.01,55.47c0,0.43,0.01,0.87,0.03,1.3c0.17,3.06,2.55,5.4,5.63,5.41
			c11.32,0.03,22.64,0.01,33.95,0.01c0.88,0,1.72-0.21,2.5-0.62c2.25-1.2,3.18-3.12,3.17-5.64C72.6,66.22,72.63,56.86,72.63,47.49z
				M49.97,91.29c1.15,0.02,2.33-1.14,2.36-2.3c0.02-1.16-1.13-2.33-2.3-2.35c-1.16-0.02-2.33,1.12-2.36,2.29
			C47.65,90.08,48.81,91.26,49.97,91.29z">
		</path>
	</g>
</svg>
												</i>
                                            <span class="mb-0">Hotline:
                                                <a href="tel:1800-123-456-7">1800-123-456-7</a><br> 
												<span>Mon - Sat: 9.00 am - 6.00 pm</span>
                                            </span>
                                        </li>
                                        <li><i
                                                class="tq-bg-theme d-inline-flex align-items-center justify-content-center rounded-circle">
<svg
	class="fill-white" xmlns="http://www.w3.org/2000/svg"
	viewBox="0 0 100 100">
	<g>
		<path d="M97.5,67.79c-0.5,3.23-1.43,6.33-3.22,9.1c-4.41,6.78-10.62,10.54-18.75,10.59c-16.99,0.1-33.98,0.05-50.97,0.02
		C13.58,87.48,4.11,79.1,2.69,68.23c-0.13-1.02-0.17-2.03-0.17-3.05c0-10.13,0.06-20.26-0.02-30.4
		c-0.08-10.87,8.14-20.67,19.38-22.15c0.86-0.11,1.72-0.16,2.58-0.16c17.05,0,34.1-0.02,51.15,0.01
		c10.79,0.02,20.23,8.3,21.74,18.98c0.03,0.24,0.09,0.48,0.14,0.72C97.5,44.06,97.5,55.92,97.5,67.79z M50.02,79.96
		c8.22,0,16.44,0,24.65,0c1.05,0,2.1-0.08,3.13-0.28c7.28-1.41,12.19-7.33,12.21-14.77c0.03-9.95,0.01-19.9,0-29.84
		c0-0.92-0.08-1.86-0.25-2.76c-1.37-7.28-7.3-12.26-14.71-12.27c-16.68-0.03-33.37-0.01-50.05,0c-0.92,0-1.85,0.1-2.76,0.28
		c-7.2,1.41-12.13,7.28-12.16,14.61c-0.04,10.04-0.05,20.08,0.01,30.12c0.02,4.27,1.57,7.96,4.72,10.91c2.94,2.75,6.49,3.99,10.47,4
		C33.52,79.97,41.77,79.96,50.02,79.96z" />
		<path
			d="M50.23,61.2c-5.05-0.03-9.57-1.47-13.53-4.5c-5.94-4.55-11.82-9.15-17.72-13.75c-1.85-1.44-2.19-3.78-0.85-5.48
		c1.35-1.72,3.64-1.97,5.52-0.52c5.48,4.23,10.97,8.44,16.38,12.75c2.9,2.31,6.06,3.81,9.8,3.87c3.24,0.05,6.26-0.78,8.86-2.75
		c6.07-4.57,12.09-9.21,18.13-13.82c0.85-0.65,1.71-1.2,2.85-1.17c1.6,0.03,2.97,0.91,3.56,2.36c0.58,1.44,0.29,3.12-0.94,4.16
		c-1.75,1.47-3.59,2.83-5.41,4.22c-4.32,3.3-8.65,6.59-12.96,9.9C59.86,59.57,55.28,61.16,50.23,61.2z" />
	</g>
</svg>
												</i><a href="mailto:username@domain.com"
                                                title="">username@domain.com</a></li>
                                        <li><i
                                                class="tq-bg-theme d-inline-flex align-items-center justify-content-center rounded-circle">
												
<svg
class="fill-white" xmlns="http://www.w3.org/2000/svg"
viewBox="0 0 100 100">
<g>
	<path d="M53.32,2.5c2.47,0.39,4.95,0.76,7.31,1.64C73.44,8.93,81.14,18.06,83.15,31.6c1.33,8.92-0.98,17.12-6.37,24.38
		c-5.87,7.89-11.77,15.75-17.69,23.6c-4.7,6.23-13.52,6.23-18.22,0c-5.92-7.85-11.82-15.72-17.69-23.59
		c-5.01-6.72-7.15-14.3-6.62-22.64c0.88-13.63,10.92-25.92,24.1-29.63c1.97-0.55,3.98-0.86,5.98-1.22C48.86,2.5,51.09,2.5,53.32,2.5
		z M24.08,35.06c0.1,6.6,1.76,11.76,5.17,16.31c5.85,7.82,11.72,15.64,17.58,23.45c1.81,2.41,4.47,2.43,6.27,0.03
		c5.89-7.83,11.79-15.66,17.63-23.53c4.36-5.88,5.91-12.52,4.74-19.72C73.25,17.81,60.22,8.37,46.35,10.29
		C34.65,11.91,24.22,21.92,24.08,35.06z">
	</path>
	<path
		d="M34.02,97.5c-1.63-0.76-2.72-1.9-2.66-3.85c0.05-1.97,1.62-3.62,3.6-3.63c10.01-0.02,20.03-0.02,30.04,0
		c1.59,0,2.97,1.1,3.45,2.63c0.5,1.6-0.08,3.29-1.47,4.26c-0.33,0.23-0.7,0.4-1.04,0.59C55.3,97.5,44.66,97.5,34.02,97.5z">
	</path>
	<path
		d="M49.99,47.1c-6.24,0-11.2-4.94-11.21-11.17c0-6.29,4.94-11.23,11.23-11.23c6.22,0.01,11.16,4.97,11.16,11.21
		C61.17,42.14,56.22,47.09,49.99,47.1z M50,32.27c-1.92-0.02-3.63,1.67-3.65,3.61c-0.02,1.92,1.67,3.63,3.61,3.65
		c1.92,0.02,3.63-1.67,3.65-3.61C53.62,33.99,51.94,32.29,50,32.27z">
	</path>
</g>
</svg>
												</i>New Orleans, Jamia Mosque</li>
                                    </ul><!-- Contact List -->
                                </div></div></div><div class="col-md-6 col-sm-6 col-lg-3"><div class="widget-box widget widget">		
		<div class="tq-widget-box d-flex flex-column position-relative w-100">
			 <h4 class="mb-0">Quick Links</h4> 				
				<ul class="d-flex flex-column list-unstyled mb-0">
				
				<li>
							<a itemprop="url" href="https://naudummy.com/muezzin/">Home &#8211; Islamic Center</a>
						</li><li>
							<a itemprop="url" href="https://naudummy.com/muezzin/salat-timings/">Salat Timings</a>
						</li><li>
							<a itemprop="url" href="https://naudummy.com/muezzin/travel-tours/">Travel &#038; Tours</a>
						</li><li>
							<a itemprop="url" href="https://naudummy.com/muezzin/online-classes/">Online Classes</a>
						</li><li>
							<a itemprop="url" href="https://naudummy.com/muezzin/lp-term-conditions/">Term Conditions</a>
						</li>				
				</ul>
				
						
		</div>
			
		</div></div>                        </div>
                    </div><!-- Footer Body -->
                    <div class="tq-footer-bottom d-flex align-items-center justify-content-between position-relative w-100">
                        <p itemprop="description" class="mb-0 text-white">Muezzin © Copyright 2025,  <a href="https://themeforest.net/user/nauthemes">All Rights Reserved</a></p>
                        <div class="tq-social-links text-white d-inline-flex align-items-center">
                            				<a class="brd-rd50" data-toggle="tooltip" data-placement="top" href="https://facebook.com" title="" itemprop="url" target="_blank"><i class="fab fa-facebook-f"></i></a>
							<a class="brd-rd50" data-toggle="tooltip" data-placement="top" href="https://twitter.com" title="" itemprop="url" target="_blank"><i class="fab fa-twitter"></i></a>
							<a class="brd-rd50" data-toggle="tooltip" data-placement="top" href="https://linkedin.com" title="" itemprop="url" target="_blank"><i class="fab fa-linkedin-in"></i></a>
							<a class="brd-rd50" data-toggle="tooltip" data-placement="top" href="https://instagram.com" title="" itemprop="url" target="_blank"><i class="fab fa-instagram"></i></a>
			                        </div><!-- Social Links -->
                    </div><!-- Footer Bottom -->
                </div>
            </div>
        </footer>

		
		 
   
</main>

<div class="gtranslate_wrapper" id="gt-wrapper-84816053"></div>			<script>
				const lazyloadRunObserver = () => {
					const lazyloadBackgrounds = document.querySelectorAll( `.e-con.e-parent:not(.e-lazyloaded)` );
					const lazyloadBackgroundObserver = new IntersectionObserver( ( entries ) => {
						entries.forEach( ( entry ) => {
							if ( entry.isIntersecting ) {
								let lazyloadBackground = entry.target;
								if( lazyloadBackground ) {
									lazyloadBackground.classList.add( 'e-lazyloaded' );
								}
								lazyloadBackgroundObserver.unobserve( entry.target );
							}
						});
					}, { rootMargin: '200px 0px 200px 0px' } );
					lazyloadBackgrounds.forEach( ( lazyloadBackground ) => {
						lazyloadBackgroundObserver.observe( lazyloadBackground );
					} );
				};
				const events = [
					'DOMContentLoaded',
					'elementor/lazyload/observe',
				];
				events.forEach( ( event ) => {
					document.addEventListener( event, lazyloadRunObserver );
				} );
			</script>
			<script type="text/javascript" src="https://naudummy.com/muezzin/wp-content/plugins/ingeniofy-plus/assets/js/bootstrap.min.js?ver=1.0.0" id="plus_bootstrap5-js"></script>
<script type="text/javascript" src="https://naudummy.com/muezzin/wp-content/plugins/ingeniofy-plus/assets/js/swiper-bundle.min.js?ver=1.0.0" id="plus_swiper-bundle-js"></script>
<script type="text/javascript" src="https://naudummy.com/muezzin/wp-content/plugins/ingeniofy-plus/assets/js/plus_scripts.js?ver=1.0.0" id="plus_scripts-js"></script>
<script type="text/javascript" src="https://naudummy.com/muezzin/wp-content/plugins/ingeniofy/js/owl.carousel.min.js?ver=1.0.0" id="owl-carousel-js"></script>
<script type="text/javascript" src="https://naudummy.com/muezzin/wp-content/plugins/ingeniofy/js/custom-slider.js?ver=1.0.0" id="slider-script-js"></script>
<script type="text/javascript" src="https://naudummy.com/muezzin/wp-content/plugins/ingeniofy/js/musicplayer-min.js?ver=1.0.0" id="musicplayer-min-js"></script>
<script type="text/javascript" src="https://naudummy.com/muezzin/wp-includes/js/dist/hooks.min.js?ver=4d63a3d491d11ffd8ac6" id="wp-hooks-js"></script>
<script type="text/javascript" src="https://naudummy.com/muezzin/wp-includes/js/dist/i18n.min.js?ver=5e580eb46a90c2b997e6" id="wp-i18n-js"></script>
<script type="text/javascript" id="wp-i18n-js-after">
/* <![CDATA[ */
wp.i18n.setLocaleData( { 'text direction\u0004ltr': [ 'ltr' ] } );
/* ]]> */
</script>
<script type="text/javascript" src="https://naudummy.com/muezzin/wp-content/plugins/contact-form-7/includes/swv/js/index.js?ver=6.0.6" id="swv-js"></script>
<script type="text/javascript" id="contact-form-7-js-before">
/* <![CDATA[ */
var wpcf7 = {
    "api": {
        "root": "https:\/\/naudummy.com\/muezzin\/wp-json\/",
        "namespace": "contact-form-7\/v1"
    },
    "cached": 1
};
/* ]]> */
</script>
<script type="text/javascript" src="https://naudummy.com/muezzin/wp-content/plugins/contact-form-7/includes/js/index.js?ver=6.0.6" id="contact-form-7-js"></script>
<script type="text/javascript" src="https://naudummy.com/muezzin/wp-content/plugins/charitable/assets/js/charitable-frontend.min.js?ver=1.8.4.8" id="charitable-frontend-v2-js"></script>
<script type="text/javascript" id="bootstrap-js-extra">
/* <![CDATA[ */
var ajax_var = {"url":"https:\/\/naudummy.com\/muezzin\/wp-admin\/admin-ajax.php","nonce":"828e0e7983"};
/* ]]> */
</script>
<script type="text/javascript" src="https://naudummy.com/muezzin/wp-content/themes/taqwa/assets/js/bootstrap.min.js?ver=1.0.0" id="bootstrap-js"></script>
<script type="text/javascript" src="https://naudummy.com/muezzin/wp-content/themes/taqwa/assets/js/themejs/fancybox.min.js?ver=1.0.0" id="fancybox-js"></script>
<script type="text/javascript" src="https://naudummy.com/muezzin/wp-content/themes/taqwa/assets/js/themejs/perfect-scrollbar.min.js?ver=1.0.0" id="perfect-scrollbar-js"></script>
<script type="text/javascript" src="https://naudummy.com/muezzin/wp-content/themes/taqwa/assets/js/themejs/custom-scripts.js?ver=1.0.0" id="taqwa-custom-scripts-js"></script>
<script type="text/javascript" src="//code.jivosite.com/widget/sMDBcnf9C1?ver=1.3.6.1" id="jivosite_widget_code-js"></script>
<script type="text/javascript" id="gt_widget_script_84816053-js-before">
/* <![CDATA[ */
window.gtranslateSettings = /* document.write */ window.gtranslateSettings || {};window.gtranslateSettings['84816053'] = {"default_language":"en","languages":["ar","nl","en","fr","de","hi","it","fa","es","tr","ur"],"url_structure":"none","flag_style":"2d","wrapper_selector":"#gt-wrapper-84816053","alt_flags":[],"float_switcher_open_direction":"top","switcher_horizontal_position":"right","switcher_vertical_position":"bottom","flags_location":"\/muezzin\/wp-content\/plugins\/gtranslate\/flags\/"};
/* ]]> */
</script><script src="https://naudummy.com/muezzin/wp-content/plugins/gtranslate/js/float.js?ver=6.7.2" data-no-optimize="1" data-no-minify="1" data-gt-orig-url="/muezzin/popper.js" data-gt-orig-domain="naudummy.com" data-gt-widget-id="84816053" defer></script>
</body>

</html>

<!-- Page cached by LiteSpeed Cache 6.5.4 on 2025-04-25 14:47:51 -->